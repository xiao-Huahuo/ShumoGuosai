"""原反馈策略的物理边界MILP；自由单段充电用单调投影的等值下界证书。"""

import time

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog
from scipy.optimize._highspy import _core as highs_core
from scipy.sparse import coo_matrix

from policy import CAP, E_MIN, E_MAX, ETA_C, ETA_D, PHYSICAL_TOL, Policy, replay


def build_linear_policy(net, prices, weights, initial_soc, *, fixed_policy=None, reserve=None):
    net, prices, weights = [np.asarray(v, dtype=float) for v in (net, prices, weights)]
    if net.ndim != 2 or prices.shape != (net.shape[1],) or weights.shape != (net.shape[0],):
        raise ValueError("场景/电价/概率维度不符")
    if not all(np.isfinite(v).all() for v in (net, prices, weights)) or (prices <= 0).any() or (weights <= 0).any():
        raise ValueError("输入必须有限且电价/概率为正")
    if not np.isclose(weights.sum(), 1, atol=1e-12) or not E_MIN <= initial_soc <= E_MAX:
        raise ValueError("概率或初态不符")
    s, t = net.shape
    if reserve is None and fixed_policy is not None:
        reserve = fixed_policy.reserve
    reserve = np.zeros(t) if reserve is None else np.asarray(reserve, dtype=float)
    if reserve.shape != (t,) or not np.isfinite(reserve).all() or (reserve < 0).any() or (reserve > E_MAX-E_MIN).any():
        raise ValueError("动态SOC安全裕度长度或数值不符")
    if fixed_policy is not None and not np.array_equal(fixed_policy.reserve, reserve):
        raise ValueError("固定策略与线性MILP动态SOC安全裕度不一致")
    g, cp, rp = [np.arange(k*t, (k+1)*t) for k in range(3)]
    blocks = [np.arange(3*t+k*s*t, 3*t+(k+1)*s*t).reshape(s, t) for k in range(13)]
    c, r, q, w, e, z, reserve_active, *selectors = blocks
    lr, lc = selectors[:3], selectors[3:]
    size = 3*t+13*s*t
    objective, lo, hi, integer = np.zeros(size), np.zeros(size), np.full(size, np.inf), np.zeros(size)
    grid_upper = np.maximum(net.max(0), 0)+CAP
    objective[g] = prices; objective[q] = 5*weights[:, None]*prices
    hi[g], hi[cp], hi[rp] = grid_upper, CAP, CAP
    hi[c], hi[r], hi[q], hi[w] = CAP, CAP, np.maximum(net, 0), np.maximum(grid_upper-net, 0)
    lo[e], hi[e] = E_MIN, E_MAX
    for block in (z, reserve_active, *lr, *lc):
        hi[block] = 1; integer[block] = 1
    hi[z[net < 0]] = 0
    free_charge = fixed_policy is None
    if free_charge:
        # z=sum(lr)，且lr为二元变量、z在[0,1]；z的整数性已由等式隐含。
        integer[z] = 0
        for block in lc:
            hi[block] = 0; integer[block] = 0
    if fixed_policy is None:
        # 单段反馈下提高充电上限使逐步SOC不减、紧急购电不增；见等价性文档的支配性证明。
        # 仅优化时消去被支配的选择；固定策略回放必须保留调用者指定的上限。
        lo[cp] = CAP
    else:
        if fixed_policy.charge_cap.shape != (t,) or fixed_policy.grid.shape != (t,):
            raise ValueError("线性编码只支持单段策略")
        for indices, values in ((g, fixed_policy.grid), (cp, fixed_policy.charge_cap), (rp, fixed_policy.discharge_cap)):
            if (values < lo[indices]-1e-8).any() or (values > hi[indices]+1e-8).any():
                raise ValueError("固定策略超出线性编码的物理上界")
            values = np.clip(values, lo[indices], hi[indices])
            lo[indices] = values; hi[indices] = values
    rows, cols, coefficients, lower, upper = [], [], [], [], []
    def add(terms, rhs, equal=False):
        index = len(upper)
        for column, value in terms:
            rows.append(index); cols.append(int(column)); coefficients.append(value)
        lower.append(rhs if equal else -np.inf); upper.append(rhs)
    for j in range(s):
        for i in range(t):
            n = float(net[j, i]); ci, ri, qi, wi, ei, zi = [int(v[j, i]) for v in (c, r, q, w, e, z)]
            previous = int(e[j, i-1]) if i else None
            threshold = E_MIN+float(reserve[i])
            positive_available_max = ETA_D*(E_MAX-threshold)
            negative_available_max = ETA_D*float(reserve[i])
            reserve_binary = int(reserve_active[j, i])
            if i == 0:
                active = int(initial_soc >= threshold)
                lo[reserve_binary] = active
                hi[reserve_binary] = active
            add([(g[i], 1), (ri, 1), (qi, 1), (ci, -1), (wi, -1)], n, True)
            add([(ei, 1), (ci, -ETA_C), (ri, 1/ETA_D)]+([(previous, -1)] if i else []), 0 if i else initial_soc, True)
            add([(ci, 1), (cp[i], -1)], 0); add([(ri, 1), (rp[i], -1)], 0)
            room_max = (E_MAX-E_MIN)/ETA_C if i else (E_MAX-initial_soc)/ETA_C
            add([(ci, 1)]+([(previous, 1/ETA_C)] if i else []), E_MAX/ETA_C if i else room_max)
            add([(ri, 1), (reserve_binary, -CAP)], 0)
            if i:
                add([(previous, ETA_D), (reserve_binary, -positive_available_max)], ETA_D*threshold)
                add([(previous, -ETA_D), (reserve_binary, negative_available_max)], -ETA_D*E_MIN)
                add([(ri, 1), (previous, -ETA_D), (reserve_binary, negative_available_max)], -ETA_D*E_MIN)
            else:
                add([(ri, 1), (reserve_binary, negative_available_max)], ETA_D*(initial_soc-E_MIN))
            add([(ci, 1), (zi, CAP)], CAP); add([(ri, 1), (zi, -CAP)], 0)
            add([(qi, 1), (zi, -max(n, 0))], 0)
            surplus_max = max(float(grid_upper[i])-n, 0)
            add([(wi, 1), (zi, surplus_max)], surplus_max)
            add([(int(v[j, i]), 1) for v in lr]+[(zi, -1)], 0, True)
            if not free_charge:
                add([(int(v[j, i]), 1) for v in lc]+[(zi, 1)], 1, True)
            # 分支激活常数分别为：CAP、max(n,0)、可用电量上界，以及CAP、Gmax-n、容量空间上界。
            add([(rp[i], 1), (ri, -1), (lr[0][j, i], CAP)], CAP)
            deficit_max = max(n, 0)
            add([(g[i], -1), (ri, -1), (lr[1][j, i], deficit_max)], deficit_max-n)
            add([(ri, -1), (lr[2][j, i], positive_available_max)]+
                ([(previous, ETA_D)] if i else []),
                positive_available_max+ETA_D*threshold if i
                else positive_available_max-ETA_D*(initial_soc-threshold))
            if not free_charge:
                add([(cp[i], 1), (ci, -1), (lc[0][j, i], CAP)], CAP)
                add([(g[i], 1), (ci, -1), (lc[1][j, i], surplus_max)], surplus_max+n)
                add([(ci, -1), (lc[2][j, i], room_max)]+([(previous, -1/ETA_C)] if i else []),
                    room_max-E_MAX/ETA_C if i else 0)
            # 原整数反馈分支隐含的有效约束；仅加强松弛，不删除任何可行反馈策略。
            add([(qi, 1), (lr[0][j, i], -deficit_max), (lr[2][j, i], -deficit_max)], 0)
            if not free_charge:
                add([(wi, 1), (lc[0][j, i], -surplus_max), (lc[2][j, i], -surplus_max)], 0)
            add([(ei, 1), (lr[2][j, i], E_MAX-threshold)], E_MAX)
            if not free_charge:
                add([(ei, -1), (lc[2][j, i], E_MAX-E_MIN)], -E_MIN)
            # 同一方向的响应总量受净缺口/剩余上界约束，不能将分量上界重复相加。
            add([(ri, 1), (qi, 1), (zi, -deficit_max)], 0)
            add([(ci, 1), (wi, 1), (zi, surplus_max)], surplus_max)
            if i:
                # 当储能边界项为最小项，上一SOC必须在一时段功率可达的边界邻域。
                add([(previous, 1), (lr[2][j, i], E_MAX-threshold-CAP/ETA_D)], E_MAX)
                if not free_charge:
                    add([(previous, -1), (lc[2][j, i], E_MAX-E_MIN-ETA_C*CAP)], -E_MIN)
    matrix = coo_matrix((coefficients, (rows, cols)), shape=(len(upper), size)).tocsc()
    return objective, Bounds(lo, hi), integer, LinearConstraint(matrix, lower, upper), {"g": g, "cp": cp, "rp": rp,
                                                                                   "responses": (c, r, q, w, e), "z": z,
                                                                                   "reserve_active": reserve_active, "lr": lr,
                                                                                   "lc": lc, "free_charge": free_charge,
                                                                                   "reserve": reserve}


def linear_seed(policy, net, initial_soc, indices, size):
    vector = np.zeros(size)
    for key, values in (("g", policy.grid), ("cp", policy.charge_cap), ("rp", policy.discharge_cap)):
        vector[indices[key]] = values
    for j, path in enumerate(net):
        response = replay(policy, path, initial_soc)
        for columns, key in zip(indices["responses"], ("charge", "discharge", "emergency", "unused", "soc")):
            vector[columns[j]] = response[key]
        previous = initial_soc
        for i, n in enumerate(path):
            x = n-policy.grid[i]; deficit = x >= 0
            vector[indices["z"][j, i]] = int(deficit)
            available = max(ETA_D*(previous-E_MIN-policy.reserve[i]), 0)
            vector[indices["reserve_active"][j, i]] = int(previous >= E_MIN+policy.reserve[i])
            rmin = np.argmin([policy.discharge_cap[i], max(x, 0), available])
            cmin = np.argmin([policy.charge_cap[i], max(-x, 0), (E_MAX-previous)/ETA_C])
            if deficit:
                vector[indices["lr"][rmin][j, i]] = 1
            elif not indices["free_charge"]:
                vector[indices["lc"][cmin][j, i]] = 1
            previous = response["soc"][i]
    return vector


def polish_linear_seed(policy, net, initial_soc, objective, bounds, integer, constraints, indices, *, seconds=30):
    """固定当前响应分支求局部LP，仅改善可行上界；它的最优值从不作全局下界。"""
    started = time.perf_counter()
    vector = linear_seed(policy, net, initial_soc, indices, len(objective))
    initial_cost = float(objective@vector)
    equality = constraints.lb == constraints.ub
    rounds = 0
    for _ in range(1000):
        remaining = seconds-(time.perf_counter()-started)
        if remaining <= 0:
            break
        lo, hi = bounds.lb.copy(), bounds.ub.copy()
        lo[integer == 1] = hi[integer == 1] = vector[integer == 1]
        solved = linprog(objective, A_eq=constraints.A[equality], b_eq=constraints.ub[equality],
                         A_ub=constraints.A[~equality], b_ub=constraints.ub[~equality], bounds=np.column_stack([lo, hi]),
                         method="highs", options={"time_limit": remaining, "primal_feasibility_tolerance": 1e-8,
                                                  "dual_feasibility_tolerance": 1e-8})
        if not solved.success:
            break
        candidate = Policy(*[np.maximum(solved.x[indices[key]], 0) for key in ("g", "cp", "rp")],
                           indices["reserve"])
        updated = linear_seed(candidate, net, initial_soc, indices, len(objective))
        if float(objective@updated) >= float(objective@vector)-1e-5:
            break
        policy, vector = candidate, updated
        rounds += 1
    return vector, {"rounds": rounds, "seconds": time.perf_counter()-started, "initial_cost": initial_cost,
                    "candidate_cost": float(objective@vector), "role": "local_region_feasible_upper_bound_only"}


def solve_linear_policy(net, prices, weights, initial_soc, *, gap=.01, time_limit=900,
                        fixed_policy=None, seed_policy=None, log=False, reserve=None,
                        threads=1):
    started = time.perf_counter()
    objective, bounds, integer, constraints, indices = build_linear_policy(
        net, prices, weights, initial_soc, fixed_policy=fixed_policy, reserve=reserve)
    refinement = None
    if seed_policy is not None:
        polish_started = time.perf_counter()
        before_dominance = None
        if fixed_policy is None:
            seed_policy = Policy(seed_policy.grid, np.full(len(prices), CAP),
                                 seed_policy.discharge_cap, indices["reserve"])
            # 先在原策略类改善初值，避免过早固定cp使局部分支LP停在较差初值。
            seed_lower = bounds.lb.copy()
            seed_lower[indices["cp"]] = 0
            vector, before_dominance = polish_linear_seed(
                seed_policy, net, initial_soc, objective, Bounds(seed_lower, bounds.ub.copy()),
                integer, constraints, indices)
            seed_policy = Policy(vector[indices["g"]], np.full(len(prices), CAP),
                                 vector[indices["rp"]], indices["reserve"])
        vector, refinement = polish_linear_seed(
            seed_policy, net, initial_soc, objective, bounds, integer, constraints, indices,
            seconds=max(30-(time.perf_counter()-polish_started), 0))
        if before_dominance is not None:
            refinement = {"before_dominance": before_dominance, "after_dominance": refinement,
                          "rounds": before_dominance["rounds"]+refinement["rounds"],
                          "seconds": time.perf_counter()-polish_started,
                          "initial_cost": before_dominance["initial_cost"], "candidate_cost": float(objective@vector),
                          "role": "local_region_feasible_upper_bound_only"}
    # 使用已锁定SciPy 1.16.3内置的HiGHS 1.8绑定，以传入经过逐行检查的完整可行初值。
    highs_core._Highs.resetGlobalScheduler(True)
    solver = highs_core._Highs()
    # HiGHS以可行上界U归一化gap，本项目以全局下界L归一化；换算保证(U-L)/L仍不超过gap。
    internal_gap = gap/(1+gap)
    for key, value in {"mip_rel_gap": internal_gap, "time_limit": max(time_limit-(time.perf_counter()-started), .01), "output_flag": log, "threads": int(threads),
                       "mip_feasibility_tolerance": 1e-8, "primal_feasibility_tolerance": 1e-8}.items():
        if solver.setOptionValue(key, value) == highs_core.HighsStatus.kError:
            raise ValueError(f"HiGHS参数不受当前锁定版本支持：{key}")
    lp, matrix = highs_core.HighsLp(), constraints.A
    lp.num_col_, lp.num_row_ = len(objective), matrix.shape[0]
    lp.a_matrix_.num_col_, lp.a_matrix_.num_row_ = lp.num_col_, lp.num_row_
    lp.a_matrix_.format_ = highs_core.MatrixFormat.kColwise
    lp.col_cost_, lp.col_lower_, lp.col_upper_ = objective, bounds.lb, bounds.ub
    lp.row_lower_, lp.row_upper_ = constraints.lb, constraints.ub
    lp.a_matrix_.start_, lp.a_matrix_.index_, lp.a_matrix_.value_ = matrix.indptr, matrix.indices, matrix.data
    lp.integrality_ = [highs_core.HighsVarType(int(v)) for v in integer]
    if solver.passModel(lp) == highs_core.HighsStatus.kError:
        raise ValueError("HiGHS未能加载物理边界线性模型")
    if seed_policy is not None:
        activity = matrix@vector
        violation = max(float(np.max(bounds.lb-vector)), float(np.max(vector-bounds.ub)),
                        float(np.max(constraints.lb-activity)), float(np.max(activity-constraints.ub)))
        if violation > PHYSICAL_TOL:
            raise ValueError(f"完整可行初值未通过线性编码逐行核验：{violation}")
        seed = highs_core.HighsSolution(); seed.col_value = vector; seed.value_valid = True
        if solver.setSolution(seed) == highs_core.HighsStatus.kError:
            raise ValueError("HiGHS拒绝已校验初值")
    if solver.run() == highs_core.HighsStatus.kError:
        raise ValueError("HiGHS求解器错误")
    solved = solver.getInfo()
    lower = float(solved.mip_dual_bound)
    info = {"status": solver.modelStatusToString(solver.getModelStatus()), "solver": "HiGHS_monotone_charge_bound_MILP" if fixed_policy is None else "HiGHS_physical_bound_linear_MILP",
            "solver_version": solver.version(), "time_limit": time_limit,
            "requested_gap": gap, "solve_seconds": time.perf_counter()-started, "reliable": False,
            "continuous_variables": int((integer == 0).sum()), "binary_variables": int(integer.sum()),
            "constraints": int(constraints.A.shape[0]), "nodes": int(solved.mip_node_count),
            "dual_bound": lower if np.isfinite(lower) else None, "seed_verified": seed_policy is not None,
            "seed_refinement": refinement, "highs_primal_relative_gap_target": internal_gap,
            "maximum_charge_cap_dominance_presolve": fixed_policy is None, "response_branch_valid_cuts": True}
    if solved.primal_solution_status != highs_core.kSolutionStatusFeasible:
        return None, None, info
    vector = np.asarray(solver.getSolution().col_value)
    policy = Policy(*[np.maximum(vector[indices[key]], 0) for key in ("g", "cp", "rp")],
                    indices["reserve"])
    responses = [replay(policy, row, initial_soc) for row in net]
    raw = np.stack([vector[v] for v in indices["responses"]], axis=-1)
    exact = np.array([np.array([row[key] for key in ("charge", "discharge", "emergency", "unused", "soc")]).T for row in responses])
    raw_difference = float(np.max(np.abs(raw-exact)))
    activity = constraints.A@vector
    feasibility_error = max(float(np.max(bounds.lb-vector)), float(np.max(vector-bounds.ub)),
                            float(np.max(constraints.lb-activity)), float(np.max(activity-constraints.ub)), 0.)
    integrality_error = float(np.max(np.abs(vector[integer == 1]-np.rint(vector[integer == 1]))))
    projection_error = max(float(np.max(raw[..., 4]-exact[..., 4])),
                           float(np.max(exact[..., 2]-raw[..., 2])), 0.) if fixed_policy is None else None
    value = float(prices@policy.grid+sum(5*p*(prices@row["emergency"]) for p, row in zip(weights, responses)))
    raw_objective = float(solved.objective_function_value)
    cost_nonincrease = bool(value <= raw_objective+PHYSICAL_TOL)
    certified_gap = max(value-lower, 0)/max(abs(lower), 1e-8) if np.isfinite(lower) else None
    error = projection_error if fixed_policy is None else raw_difference
    info.update(objective=value, optimizer_objective=raw_objective, mip_gap=certified_gap,
                monotone_charge_bound=fixed_policy is None, raw_response_difference_kwh=raw_difference,
                mapping_error_kwh=raw_difference if fixed_policy is not None else None,
                monotone_projection_error_kwh=projection_error, linear_feasibility_error=feasibility_error,
                integrality_error=integrality_error, mapped_policy_cost_not_above_raw_objective=cost_nonincrease,
                certificate_error_definition="SOC_dominance_and_emergency_nonincrease" if fixed_policy is None else "exact_mapping",
                reliable=bool(certified_gap is not None and error <= PHYSICAL_TOL
                              and feasibility_error <= PHYSICAL_TOL and integrality_error <= 1e-8
                              and lower <= value+PHYSICAL_TOL and certified_gap <= gap+1e-8 and cost_nonincrease))
    if error > PHYSICAL_TOL or feasibility_error > PHYSICAL_TOL or integrality_error > 1e-8 or not cost_nonincrease:
        raise ValueError("线性MILP可行性或原反馈投影证书不符；不得执行原始场景轨迹")
    return policy, responses, info

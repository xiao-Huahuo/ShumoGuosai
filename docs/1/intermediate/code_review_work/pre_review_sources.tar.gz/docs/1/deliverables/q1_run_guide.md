# Q1 边际价值强化版运行与输入输出说明

当前依据 [第一问_MILP_边际价值强化版.md](../final/第一问_MILP_边际价值强化版.md)。本次使用模型已声明的右端点、零阶保持、母线侧充放电量、双单程0.9效率、不售电和允许弃光假设。用户另外确认：功率上限按5000/6准确计算；最终文件改为CSV。没有增加电池损耗费用、售电、二级吞吐量目标或其他建模假设。

在项目根目录执行：

```sh
uv run --with-requirements src/q1/requirements.txt python src/q1/run.py
```

运行针对性验收：

```sh
uv run --with-requirements src/q1/requirements.txt python src/q1/test_q1.py
uv run --with-requirements src/q1/requirements.txt python src/q1/test_analysis.py
```

首次运行由uv提供锁定版本的numpy、scipy、openpyxl、matplotlib。openpyxl仅用于读取题目原始附件，不生成Excel输出。本次环境为Python 3.12，具体版本与源文件SHA-256见 `outputs/q1/raw/run_manifest.json`。运行入口是 `src/q1/run.py`，根目录原有空文件 `main.py` 未改动。

| 文件 | 内容 |
|---|---|
| `inputs/q1/raw/attachment1.csv` | 原附件144行时间、电价、负荷功率、光伏预测功率的CSV副本 |
| `inputs/q1/processed/timeseries.csv` | 144时段映射及kW→kWh后的完整输入 |
| `inputs/q1/processed/parameters.json` | 模型参数、章节来源和用户确认的两个调整 |
| `outputs/processed/q1/result1.csv` | 完整输入与六类决策变量、时段初末储量、SOC和费用，共144行 |
| `outputs/processed/q1/daily_summary.csv` | 全日电量、费用、充放电量、弃光、损耗及0:00/24:00储量 |
| `outputs/processed/q1/table1_purchase.csv` | 10、12、14、16、18、20点开始的六个10分钟区间购电量 |
| `outputs/processed/q1/table2_storage.csv` | 六个4小时区间的充电量和放电量 |
| `outputs/processed/q1/efficiency_comparison.csv` | 主模型、0.85、0.95、sqrt(0.9)四情景汇总 |
| `outputs/q1/raw/schedule_*.csv` | 各效率情景完整144时段轨迹 |
| `outputs/q1/raw/solution_*.json` | 原始求解变量、目标值、下界、gap和求解器设置 |
| `outputs/q1/raw/validation.json` | 四情景物理与最优性检查、CSV关闭后回读检查 |
| `outputs/q1/raw/tests.json` | 解析测试、压力测试与篡改拦截测试结果 |
| `outputs/processed/q1/dispatch.png/.svg/.pdf` | 输入功率、电价、调度及储电量图 |
| `outputs/processed/q1/efficiency.png/.svg/.pdf` | 效率成本对比和储电轨迹图 |
| `outputs/processed/q1/report.html` | 可直接打开的输入输出报告，表格可展开及滚动 |
| `docs/1/deliverables/q1_results.md` | 结果表与合理性说明 |
| `docs/1/deliverables/q1_implementation_acceptance.md` | 逐项验收、挖洞和假设审查 |
| `docs/1/deliverables/q1_source_line_traceability.csv` | 最终稿每个非空源行与实现、验收证据的对应索引 |

CSV使用UTF-8无BOM、逗号分隔；小数点为英文句点，数值字段不使用千位分隔符。文件保留浮点求解精度，报告显示6位小数。CSV的最后一行 `23:50-24:00` 属于本日最后一个10分钟时段。

`result1.csv` 字段：

| 字段 | 含义/单位 |
|---|---|
| t | 1至144的时段编号 |
| source_excel_row | 原始附件行号（含表头） |
| source_endpoint | 原附件时间标签，原Excel time类型转换为文本后可能包含秒 |
| interval | 本时段半开区间 `[开始, 结束)` 的文本标签 |
| start_minute / end_minute | 自当日0:00起的分钟数 |
| price_yuan_per_kwh | 本时段购电单价，元/kWh |
| load_kw / pv_kw | 原始负荷功率/光伏预测功率，kW |
| load_kwh / pv_kwh | 零阶保持换算后的负荷/光伏电量，kWh |
| G_kwh | 外网购电量，kWh |
| C_kwh | 微网母线送入储能设备的电量，kWh |
| D_kwh | 储能设备送至微网母线的电量，kWh |
| E_kwh | 时段结束后的电池内部储电量，kWh |
| W_kwh | 弃光电量，kWh |
| u | 二元运行状态，1允许充电、0允许放电；空闲时可取任一值，保留求解器浮点表示 |
| E_start_kwh | 时段开始时的电池内部储电量，kWh |
| soc_fraction | E_kwh/12000；比例值，0.5即50% |
| cost_yuan | price_yuan_per_kwh×G_kwh，元 |

四小时区间内可以有不同10分钟时段分别充电和放电，因此表2中同一行充电总量与放电总量都为正不代表违反互斥。

程序将附件的缺失、负电价、负功率、时间重复、错位及非数值数据视为错误，不自动填补。模型解必须通过全部检查才进入CSV暂存写入；暂存文件关闭并回读通过后，才替换正式CSV。若运行报错，不能将既有旧文件当作本轮结果，应以成功运行日志与 `run_manifest.json` 为准。

求解器使用HiGHS，要求MIP相对gap为0；原生整数、原始与对偶可行性容差均为1e-9，最终独立物理验收容差保持模型规定的1e-6。容差属于数值实现设置，不改变数学约束。最优性是针对该模型、该数据及已声明数值容差的证书；不表示最优策略唯一。

## 新版11.3–11.8分析交付

运行同一入口会完整生成以下分析。每种效率与负荷、光伏的−5%/0/+5%交叉组合，共36情景；每个情景都重新求解MILP、核验物理与最优性、固定最优模式提取边际量，并单独放宽容量、充电功率、放电功率。主情景使用1/10/100三种步长，其他情景使用1，共114次放宽实验。

| 路径（项目根目录起） | 行数/用途 |
|---|---|
| `outputs/processed/q1/baseline_comparison.csv` | 3个嵌套基准的成本与电量 |
| `outputs/processed/q1/incremental_benefits.csv` | 两步增量收益与总节约；不是唯一因果归因 |
| `outputs/processed/q1/lp_diagnosis.csv` | LPR目标、整数间隙、分数u、同时充放电数 |
| `outputs/processed/q1/marginal_values.csv` | 5184行：36×144局部μ、λ、充放阈值、实际动作、模式限制和边界活跃 |
| `outputs/processed/q1/marginal_rhs_validation.csv` | 288个等式方向，各有±0.01kWh两侧差分、状态和影子价格区间复核 |
| `outputs/processed/q1/bottleneck_values.csv` | 114次单边界放宽的原/新成本、节约、单位日价值、活跃时段及瓶颈判定 |
| `outputs/processed/q1/sensitivity_scenarios.csv` | 36组J/G/C/D/W、SOC边界、价格倍率、三类资源价值、动作与轨迹差异 |
| `outputs/processed/q1/normalized_sensitivity.csv` | 8行：四种效率下的负荷和光伏归一化成本敏感度 |
| `outputs/processed/q1/active_constraints.csv` | 5184行：每个情景每个时段的四种边界活跃标记 |
| `outputs/processed/q1/arbitrage_thresholds.csv` | 576行：四种效率下当前价格、未来价格阈值、当天未来可盈利时段数 |
| `outputs/q1/raw/analysis_schedules.csv` | 5184行：各情景真实扰动输入和G/C/D/E/W/u全量输出 |
| `outputs/q1/raw/analysis_solutions.json` | 基准、LPR、36情景、固定模式LP及114个放宽MILP的完整原始解 |
| `outputs/q1/raw/analysis_validation.json` | 物理/最优性、LP原始对偶检查、双侧差分和CSV回读记录 |
| `outputs/q1/raw/analysis_tests.json` | 7组针对性测试结果，含真实36情景和114次放宽独立核验 |
| `outputs/processed/q1/analysis_summary.json` | 完整分析汇总与数值设置 |
| `outputs/processed/q1/marginal_report.html` | 可展开的边际价值报告、36情景表和全部CSV入口 |
| `outputs/processed/q1/marginal_analysis.png/.svg/.pdf` | 阈值、基准费用和负荷×光伏热力图 |
| `outputs/processed/q1/bottleneck_analysis.png/.svg/.pdf` | 三种边界、三种放宽步长的价值对照图 |
| `docs/1/deliverables/q1_marginal_analysis.md` | 经济解释、非预期趋势和局限 |

情景名如 `eta085_l95_pv105` 表示单程效率0.85、负荷为原输入95%、光伏为105%。`analysis_schedules.csv` 的G/C/D/E/W单位为kWh，u为0/1；前缀输入字段单位与主结果一致。`*_value`和`value_per_unit_day`中容量为元/(kWh·日)、功率为元/(kW·日)，两种单位不可直接比较设备投资优先级。`economic_bottleneck`为1表示基准边界活跃且放宽后节约大于1e-6元。

`mu_yuan_per_kwh`是增加母线需求的局部成本，`lambda_yuan_per_kwh`是状态等式额外内部注入的局部价值；后者是状态等式右端项导数的负值。`charge_threshold=eta_c*lambda`，`discharge_threshold=lambda/eta_d`。固定模式只允许一个动作方向；`mode_blocks_tendency=1`说明严格阈值倾向指向当前模式不允许的方向。等号处用`indifferent_boundary`标注，不强制归为实际待机。

活跃容差为1e-6kWh。RHS差分的空值表示该方向不可行，相应status=2；status=0表示最优。非光滑处检验负向斜率≤影子价≤正向斜率（仅检验可行方向），不强制两侧相等。容量/功率结果来自重求完整MILP，不把固定模式影子价格当成全局设备扩容价值。

全部数值设置见 `inputs/q1/processed/parameters.json` 的 `analysis_settings`。主CSV与分析CSV使用真实附件输入，不掺入测试用合成算例。

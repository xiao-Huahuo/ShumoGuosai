"""一条命令完成输入归档、Q1最终模型求解、CSV回读验证与结果报告。"""

import datetime as dt
import hashlib
import platform
import shutil
import sys

import matplotlib
import numpy as np
import openpyxl
import scipy

from export import export_csv_output
from model import (DT, EPS, E_INITIAL, E_MAX, E_MIN, Q_MAX, ROOT, SCENARIOS,
                   arrays, check_solution, read_inputs, schedule_rows,
                   solve, summary, write_csv, write_json)
from report import create_figures, create_report
from analysis import ANALYSIS_SETTINGS, run_analysis
from analysis_report import create_analysis_report


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    source = ROOT / "docs/CUMCM2026Problems/C题/附件"
    input_raw = ROOT / "inputs/q1/raw"
    input_processed = ROOT / "inputs/q1/processed"
    output_raw = ROOT / "outputs/q1/raw"
    output = ROOT / "outputs/processed/q1"
    for directory in (input_raw, input_processed, output_raw, output):
        directory.mkdir(parents=True, exist_ok=True)
    originals = {"attachment1.xlsx": source / "附件1.xlsx"}
    provenance = []
    for name, original in originals.items():
        copied = input_raw / name
        shutil.copy2(original, copied)
        if sha256(original) != sha256(copied):
            raise ValueError("原始输入副本校验失败")
        provenance.append({"source": str(original.relative_to(ROOT)),
                           "copy": str(copied.relative_to(ROOT)), "sha256": sha256(copied)})
    data = read_inputs(input_raw / "attachment1.xlsx")
    write_csv(input_raw / "attachment1.csv", [{k: r[k] for k in
              ("source_endpoint", "price_yuan_per_kwh", "load_kw", "pv_kw")} for r in data])
    write_csv(input_processed / "timeseries.csv", data)
    params = {"model_source": "docs/1/final/第一问_MILP_边际价值强化版.md", "period_count": 144,
              "dt_hours": DT, "max_power_kw": 5000, "max_energy_kwh": Q_MAX,
              "max_energy_precision_decision": "用户明确确认按5000×1/6准确公式计算及验收；833.3333仅用于显示",
              "rated_capacity_kwh": 12000, "min_energy_kwh": E_MIN,
              "max_storage_kwh": E_MAX, "initial_and_terminal_kwh": E_INITIAL,
              "tolerance": EPS, "efficiency_scenarios": SCENARIOS,
              "delivery_format": "用户明确要求传统CSV，替换新版第11.9节的Excel文件载体；全部回读检查保留",
              "analysis_settings": ANALYSIS_SETTINGS,
              "assumptions": ["右端点标记", "10分钟内零阶保持", "充放电量均为微网母线侧",
                              "主模型双单程效率均0.9", "不售电且允许弃光", "仅最小化购电费，无二级目标"],
              "source_sections": {"time": "2–3", "power": "3.1", "efficiency": "4、11.8",
                                  "storage": "8", "curtailment": "5", "objective": "10", "tolerance": "11–12"}}
    write_json(input_processed / "parameters.json", params)
    write_json(input_raw / "manifest.json", provenance)
    print(f"输入：{len(data)}时段，{data[0]['interval']} 至 {data[-1]['interval']}；Qmax={Q_MAX:.12f} kWh", flush=True)
    solutions, validation, summaries = {}, {}, []
    for name, efficiency in SCENARIOS.items():
        solution = solve(data, efficiency)
        validation[name] = check_solution(data, solution)
        solutions[name] = solution
        row = {"scenario": name, **summary(data, solution)}
        summaries.append(row)
        print(f"{name}: 费用={row['cost_yuan']:.9f}元；购电={row['grid_kwh']:.9f}kWh；"
              f"弃光={row['curtail_kwh']:.9f}kWh；MIP gap={solution['solver']['mip_gap']}；物理检查通过", flush=True)
    for name, solution in solutions.items():
        write_json(output_raw / f"solution_{name}.json", solution)
        write_csv(output_raw / f"schedule_{name}.csv", schedule_rows(data, solution))
    main_solution = solutions["main"]
    validation["csv"] = export_csv_output(output, data, main_solution)
    write_json(output_raw / "validation.json", validation)
    write_csv(output / "efficiency_comparison.csv", summaries)
    write_json(output / "summary.json", summaries[0])
    create_figures(data, solutions, summaries, output)
    create_report(data, solutions, summaries, validation, output)
    analysis = run_analysis(data, solutions, output_raw, output)
    create_analysis_report(analysis, output)
    p, load, pv = arrays(data)
    run_record = {"started_utc": started, "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                  "command": "uv run --with-requirements src/q1/requirements.txt python src/q1/run.py",
                  "python": sys.version, "platform": platform.platform(),
                  "versions": {"numpy": np.__version__, "scipy": scipy.__version__,
                               "openpyxl": openpyxl.__version__, "matplotlib": matplotlib.__version__},
                  "inputs": provenance, "model_sha256": sha256(ROOT / params["model_source"]),
                  "code_sha256": {str(f.relative_to(ROOT)): sha256(f) for f in sorted((ROOT / "src/q1").glob("*.py"))},
                  "input_statistics": {"records": len(data), "price_min": float(p.min()), "price_max": float(p.max()),
                                       "load_kwh": float(load.sum()), "pv_kwh": float(pv.sum())},
                  "output_sha256": {str(f.relative_to(ROOT)): sha256(f) for f in sorted(output.iterdir()) if f.is_file()},
                  "all_physical_and_csv_checks_passed": all(v["passed"] for v in validation.values())}
    run_record["analysis_checks_passed"] = analysis["all_checks_passed"]
    run_record["analysis_scenarios"] = len(analysis["scenarios"])
    write_json(output_raw / "run_manifest.json", run_record)
    print(f"CSV写入关闭回读通过；正式结果：{output / 'result1.csv'}", flush=True)
    print(f"输入输出可视报告：{output / 'report.html'}", flush=True)


if __name__ == "__main__":
    main()

"""新版分析验收：解析边际量、真实情景、独立重算和反向篡改。"""

import copy
import io
import itertools
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from analysis import (active_sets, checked_analysis_csv, local_marginals,
                      rhs_validation, scaled_data, verify_lp)
from export import read_csv
from model import (DT, EPS, E_MAX, ROOT, SCENARIOS, arrays, build_problem,
                   check_solution, read_inputs, solve, solve_lp, summary, write_json)


class MarginalAcceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = read_inputs(ROOT / 'inputs/q1/raw/attachment1.xlsx')
        cls.raw = json.loads((ROOT / 'outputs/q1/raw/analysis_solutions.json').read_text(encoding='utf-8'))
        cls.a = json.loads((ROOT / 'outputs/processed/q1/analysis_summary.json').read_text(encoding='utf-8'))

    def test_all_36_scenarios_and_114_relaxations(self):
        expected = set(itertools.product(SCENARIOS, [-.05,0,.05], [-.05,0,.05]))
        actual = {(r['efficiency_name'],r['load_delta'],r['pv_delta']) for r in self.a['scenarios']}
        self.assertEqual(actual, expected)
        count = 0
        for row in self.a['scenarios']:
            sraw = self.raw['scenarios'][row['scenario']]
            data = scaled_data(self.data,row['load_delta'],row['pv_delta'])
            s = sraw['solution']
            self.assertTrue(check_solution(data,s)['passed'])
            self.assertEqual(active_sets(s), sraw['active_sets'])
            for key,value in summary(data,s).items():
                self.assertEqual(row[key],value)
            for name,record in sraw['perturbations'].items():
                changed = record['solution']
                self.assertTrue(check_solution(data,changed)['passed'])
                original = s['settings']
                settings = changed['settings']
                changed_keys = [k for k in original if settings[k] != original[k]]
                self.assertEqual(len(changed_keys),1)
                parameter = changed_keys[0]
                self.assertIn(parameter,['e_max','charge_kw','discharge_kw'])
                step = settings[parameter] - original[parameter]
                values = next(v for v in self.a['bottlenecks'] if v['scenario']==row['scenario']
                              and v['resource']==name.rsplit('_',1)[0] and v['increment']==step)
                saving = s['solver']['objective_yuan'] - changed['solver']['objective_yuan']
                self.assertAlmostEqual(values['value_per_unit_day'],saving/step,delta=EPS)
                self.assertGreaterEqual(saving,-EPS)
                self.assertAlmostEqual(values['increment_period_kwh'],step if parameter=='e_max' else step/6,delta=EPS)
                count += 1
        self.assertEqual(count,114)

    def test_nested_baselines_and_analytic_no_ess(self):
        p, load, pv = arrays(self.data)
        s0, spv, sfull = (self.raw[k] for k in ('no_ess','pv_only','full'))
        for s in (s0,spv,sfull):
            self.assertTrue(check_solution(self.data,s)['passed'])
        self.assertAlmostEqual(s0['solver']['objective_yuan'],p @ np.maximum(load-pv,0),delta=EPS)
        self.assertTrue(np.all(np.array(spv['C'])<=np.maximum(pv-load,0)+EPS))
        self.assertTrue(np.all(np.array(spv['D'])<=np.maximum(load-pv,0)+EPS))
        self.assertLessEqual(sfull['solver']['objective_yuan'],spv['solver']['objective_yuan']+EPS)
        b=self.a['benefits']
        self.assertAlmostEqual(b['pv_increment_yuan']+b['flex_increment_yuan'],b['total_saving_yuan'],delta=EPS)

    def test_lp_relaxation_keeps_big_m_coupling(self):
        problem=build_problem(self.data,.9)
        s=self.raw['lp_relaxation']
        x=np.concatenate([s['variables'][v] for v in problem['index']])
        lhs=problem['a']@x
        self.assertTrue(np.all(lhs>=problem['lb']-EPS))
        self.assertTrue(np.all(lhs<=problem['ub']+EPS))
        self.assertTrue(np.all(x>=problem['lower']-EPS))
        self.assertTrue(np.all(x<=problem['upper']+EPS))
        self.assertAlmostEqual(problem['objective']@x,s['objective_yuan'],delta=EPS)
        u=np.array(s['variables']['u']); c=np.array(s['variables']['C']); d=np.array(s['variables']['D'])
        self.assertEqual(self.a['lp_diagnosis']['fractional_modes'],np.sum((u>EPS)&(u<1-EPS)))
        self.assertEqual(self.a['lp_diagnosis']['simultaneous_periods'],np.sum((c>EPS)&(d>EPS)))
        self.assertLessEqual(s['objective_yuan'],self.a['lp_diagnosis']['milp_cost_yuan']+EPS)

    def test_analytic_shadow_sign_and_price_threshold(self):
        # 两时段、首段低价、末段100kWh负荷。初末均6000，充放边界不活跃。
        data=[{'price_yuan_per_kwh':.1,'load_kwh':0.,'pv_kwh':0.,'interval':'00:00-00:10'},
              {'price_yuan_per_kwh':1.,'load_kwh':100.,'pv_kwh':0.,'interval':'00:10-00:20'}]
        s=solve(data,.9)
        rows,problem,result,checks=local_marginals(data,s,'analytic')
        self.assertAlmostEqual(result.fun,100*.1/.81,delta=EPS)
        self.assertAlmostEqual(rows[0]['mu_yuan_per_kwh'],.1,delta=EPS)
        self.assertAlmostEqual(rows[1]['mu_yuan_per_kwh'],.1/.81,delta=EPS)
        self.assertAlmostEqual(rows[0]['lambda_yuan_per_kwh'],.1/.9,delta=EPS)
        self.assertAlmostEqual(rows[1]['lambda_yuan_per_kwh'],.1/.9,delta=EPS)
        self.assertEqual(len(rhs_validation(problem,result)),4)
        bad=copy.deepcopy(result)
        bad.eqlin.marginals *= -1
        with self.assertRaises(ValueError):
            verify_lp(problem,bad)
        # 无效率套利收益时不能强行充放：0.9*.81小于当前价1。
        data[0]['price_yuan_per_kwh']=1.; data[1]['price_yuan_per_kwh']=.9
        no_gain=solve(data,.9)
        self.assertAlmostEqual(sum(no_gain['C']),0,delta=EPS)
        self.assertAlmostEqual(sum(no_gain['D']),0,delta=EPS)

    def test_actual_rhs_slopes_and_local_thresholds(self):
        rows=read_csv(ROOT/'outputs/processed/q1/marginal_rhs_validation.csv')
        self.assertEqual(len(rows),288)
        self.assertEqual({(r['kind'],int(r['t'])) for r in rows},set(itertools.product(['bus_demand','internal_injection'],range(1,145))))
        for r in rows:
            shadow=float(r['shadow_dJ_db'])
            if r['minus_slope']:
                self.assertLessEqual(float(r['minus_slope']),shadow+EPS)
            if r['plus_slope']:
                self.assertLessEqual(shadow,float(r['plus_slope'])+EPS)
        local=read_csv(ROOT/'outputs/processed/q1/marginal_values.csv')
        self.assertEqual(len(local),36*144)
        by_key={r['scenario']:r for r in self.a['scenarios']}
        for r in local:
            eta=by_key[r['scenario']]['eta_c']
            self.assertAlmostEqual(float(r['charge_threshold']),eta*float(r['lambda_yuan_per_kwh']),delta=EPS)
            self.assertAlmostEqual(float(r['discharge_threshold']),float(r['lambda_yuan_per_kwh'])/eta,delta=EPS)
            if r['actual_action']=='charge':
                self.assertGreaterEqual(float(r['charge_gain']),-EPS)
            if r['actual_action']=='discharge':
                self.assertGreaterEqual(float(r['discharge_gain']),-EPS)

    def test_full_input_output_csv_and_normalized_sensitivity(self):
        rows=read_csv(ROOT/'outputs/q1/raw/analysis_schedules.csv')
        self.assertEqual(len(rows),36*144)
        grouped={key:[] for key in self.raw['scenarios']}
        for row in rows:
            grouped[row['scenario']].append(row)
        for case in self.a['scenarios']:
            data=scaled_data(self.data,case['load_delta'],case['pv_delta'])
            s=self.raw['scenarios'][case['scenario']]['solution']
            for i,r in enumerate(grouped[case['scenario']]):
                for k in data[i]:
                    self.assertEqual(r[k],str(data[i][k]))
                for k in ('G','C','D','E','W','u'):
                    self.assertEqual(float(r[k]),s[k][i])
        for r in self.a['normalized_sensitivity']:
            self.assertAlmostEqual(r['normalized_sensitivity'],
                                   (r['plus_cost_yuan']-r['minus_cost_yuan'])/(.1*r['base_cost_yuan']),delta=EPS)

    def test_independent_power_limits_and_csv_nonfinite_rejected(self):
        a=build_problem(self.data,.9,charge_kw=5001)
        b=build_problem(self.data,.9,discharge_kw=5001)
        n=len(self.data); u=a['index']['u'][0]
        self.assertAlmostEqual(a['a'][2*n,u],-5001/6,delta=EPS)
        self.assertAlmostEqual(a['a'][3*n,u],5000/6,delta=EPS)
        self.assertAlmostEqual(b['a'][2*n,u],-5000/6,delta=EPS)
        self.assertAlmostEqual(b['a'][3*n,u],5001/6,delta=EPS)
        with tempfile.TemporaryDirectory() as tmp:
            for value in (float('nan'),float('inf')):
                with self.assertRaises(ValueError):
                    checked_analysis_csv(Path(tmp)/'bad.csv',[{'value':value}])


if __name__=='__main__':
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(MarginalAcceptance))
    log=stream.getvalue(); print(log,end='')
    write_json(ROOT/'outputs/q1/raw/analysis_tests.json',{'tests_run':result.testsRun,'passed':result.wasSuccessful(),
                                                        'failures':len(result.failures),'errors':len(result.errors),'log':log})
    raise SystemExit(0 if result.wasSuccessful() else 1)

# README

本项目保存数学建模题目资料、模型文档、输入输出、求解代码和论文模板。当前正式计算入口是 `src/q1/run.py`，第一问交付使用CSV。

### 项目目录树（持续维护）

下列目录树逐文件覆盖题目资料、模型、输入、结果、源码和论文模板。技能包、技能来源说明及本机IDE配置按目录汇总；Git内部对象、Python缓存与系统缓存不属于核心文件。所有列出的文件和文件夹均附用途说明。

```text
ShumoGuosai/                                               # 数学建模项目根目录；当前正式实现为C题第一问
├── README.md                                              # 项目总览与核心目录树；文件变化后持续同步
├── AGENTS.md                                              # 代理执行规则、需求逐项验收及UTF-8要求
├── CLAUDE.md                                              # 项目协作与代码修改规则
├── 数学建模开发规范.md                                    # 建模、代码目录、结果审查、绘图及变更记录规范
├── main.py                                                # 原有空占位文件；当前求解入口为src/q1/run.py
├── .gitignore                                             # 忽略本地技能、IDE配置与技能来源目录
├── skills-lock.json                                       # 本地技能安装来源与版本锁定信息
├── docs/                                                  # 题目资料、模型文档、使用说明和变更记录
│   ├── 1/                                                 # 第一问文档；按最终、交付、中间、清理候选四类管理
│   │   ├── README.md                                      # 第一问逐文件分类说明与阅读导航
│   │   ├── final/                                         # 正式模型原稿；强化版为当前唯一执行依据，上一版保留追溯
│   │   │   ├── Q1最终优化模型-最终版.md                   # 上一版MILP原稿；内容保留，当前执行强化版
│   │   │   └── 第一问_MILP_边际价值强化版.md              # 当前最新版；MILP、局部边际阈值、经济瓶颈与36组稳健性分析
│   │   ├── deliverables/                                  # 当前结果说明、复现文档和验收附件
│   │   │   ├── q1_implementation_acceptance.md            # 强化版逐句验收、15组测试、P0–P3与假设及界面检查
│   │   │   ├── q1_results.md                              # 正式计算结果、题目表1/表2及效率对比
│   │   │   ├── q1_run_guide.md                            # 运行命令、输入输出路径、CSV字段和单位说明
│   │   │   ├── q1_source_line_traceability.csv            # 强化版1159个非空源行的原文、实现函数、代码行与验收证据
│   │   │   └── q1_marginal_analysis.md                    # 新版基准收益、边际机制、瓶颈及非预期敏感性趋势解释
│   │   ├── intermediate/                                  # 历史模型与旧稿评审；不作为当前求解依据
│   │   │   ├── Q1_最终优化模型_结合comments.md            # 历史规范化能流、LP松弛与二级目标版本
│   │   │   ├── Q1_最终优化模型修订版_结合评审comments.md  # 历史LP路线的进一步修订稿
│   │   │   ├── Q1_精简修订版_公式兼容Obsidian.md          # 历史模型精简稿与Obsidian公式排版版本
│   │   │   ├── q1_compact_review_comments.md              # 当时精简稿的评审意见及实验说明
│   │   │   ├── 临时方案.md                                # 早期方案；包含LP、KKT、对偶与敏感性分析
│   │   │   ├── 临时方案_严格审查报告.md                   # 当时临时稿的审查意见与风险证据
│   │   │   └── marginal_value_work/                       # 强化版开发过程记录；完成后用于追溯
│   │   │       ├── notes.md                               # 边际符号、分析范围、计算发现及限制记录
│   │   │       └── task_plan.md                           # 强化版逐项实现计划与验收进度
│   │   └── cleanup_candidates/                            # 已结束任务的过程笔记；候选清理但尚未删除
│   │       ├── notes.md                                   # 实现过程发现摘要；有效信息已进入交付文档
│   │       └── task_plan.md                               # 已经全部完成的任务计划与过程记录
│   ├── CUMCM2026Problems/                                 # A至E题原题、随题附件和格式文件
│   │   ├── A题/                                           # A题原始题目资料
│   │   │   ├── 附件/                                      # A题随题提供的原始数据与附件
│   │   │   │   ├── 附件3/                                 # A题随题提供的结果模板目录
│   │   │   │   │   ├── result1.xlsx                       # A题随题提供的result1结果模板；原件保留
│   │   │   │   │   ├── result2.xlsx                       # A题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx                       # A题随题提供的result3结果模板；原件保留
│   │   │   │   │   └── result4.xlsx                       # A题随题提供的result4结果模板；原件保留
│   │   │   │   ├── 附件1.xlsx                             # A题原始附件1数据/说明文件
│   │   │   │   └── 附件2.xlsx                             # A题原始附件2数据/说明文件
│   │   │   └── A题.pdf                                    # A题原始题面PDF
│   │   ├── B题/                                           # B题原始题目资料
│   │   │   ├── 附件/                                      # B题随题提供的原始数据与附件
│   │   │   │   ├── 附件1.docx                             # B题原始附件1数据/说明文件
│   │   │   │   └── 附件2.docx                             # B题原始附件2数据/说明文件
│   │   │   └── B题.pdf                                    # B题原始题面PDF
│   │   ├── C题/                                           # C题原始题目资料
│   │   │   ├── 附件/                                      # C题随题提供的原始数据与附件
│   │   │   │   ├── 附件5/                                 # 原题结果模板；当前Q1按用户要求改用CSV交付
│   │   │   │   │   ├── result1.xlsx                       # C题随题提供的result1结果模板；原件保留
│   │   │   │   │   ├── result2.xlsx                       # C题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx                       # C题随题提供的result3结果模板；原件保留
│   │   │   │   │   ├── result4-2.xlsx                     # C题随题提供的result4-2结果模板；原件保留
│   │   │   │   │   └── result4-3.xlsx                     # C题随题提供的result4-3结果模板；原件保留
│   │   │   │   ├── 附件1.xlsx                             # 一天电价、负荷与光伏预测；当前Q1的原始数据来源
│   │   │   │   ├── 附件2.xlsx                             # 2025年全年负荷与实际光伏数据；供后续问题使用
│   │   │   │   ├── 附件3.xlsx                             # 不同发布时刻的未来24小时光伏预报；供后续问题使用
│   │   │   │   └── 附件4.xlsx                             # 波动电价数据；供第四问使用
│   │   │   └── C题.pdf                                    # C题原始题面PDF
│   │   ├── D题/                                           # D题原始题目资料
│   │   │   ├── 附件/                                      # D题随题提供的原始数据与附件
│   │   │   │   ├── 附件2/                                 # D题随题提供的结果模板目录
│   │   │   │   │   ├── result1.xlsx                       # D题随题提供的result1结果模板；原件保留
│   │   │   │   │   ├── result2.xlsx                       # D题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx                       # D题随题提供的result3结果模板；原件保留
│   │   │   │   │   └── result4.xlsx                       # D题随题提供的result4结果模板；原件保留
│   │   │   │   └── 附件1.xlsx                             # D题原始附件1数据/说明文件
│   │   │   └── D题.pdf                                    # D题原始题面PDF
│   │   ├── E题/                                           # E题原始题目资料
│   │   │   ├── 附件/                                      # E题随题提供的原始数据与附件
│   │   │   │   ├── 附件2/                                 # E题随题提供的结果模板目录
│   │   │   │   │   ├── result2.xlsx                       # E题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx                       # E题随题提供的result3结果模板；原件保留
│   │   │   │   │   └── result4.xlsx                       # E题随题提供的result4结果模板；原件保留
│   │   │   │   └── 附件1.xlsx                             # E题原始附件1数据/说明文件
│   │   │   └── E题.pdf                                    # E题原始题面PDF
│   │   └── format2026.doc                                 # 随题提供的2026格式文件
│   ├── CHANGE_HISTORY.md                                  # 按现状、实施方案、完成状态记录每次任务
│   ├── C题.md                                             # C题题面转写、各问要求与储能参数附录
│   └── 数学建模技能清单.md                                # 本地技能分类、用途与选用参考
├── inputs/                                                # 按照题号保存原始输入和预处理输入
│   └── q1/                                                # 第一问输入
│       ├── processed/                                     # 经过时间映射和单位换算的求解输入
│       │   ├── parameters.json                            # 储能参数、四种效率情景和用户确认的计算口径
│       │   └── timeseries.csv                             # 144时段输入；含右端点映射与kW转kWh结果
│       └── raw/                                           # 原始数据副本与来源追溯记录
│           ├── attachment1.csv                            # 原附件时间、电价、负荷功率、光伏功率的CSV副本
│           ├── attachment1.xlsx                           # C题附件1原始工作簿副本；仅用于读取输入
│           └── manifest.json                              # 原始附件路径、副本路径和SHA-256
├── outputs/                                               # 按规范保存原始结果和整理后的交付结果
│   ├── processed/                                         # 面向阅读、论文及交付的整理结果
│   │   └── q1/                                            # 第一问正式CSV结果与科研图表
│   │       ├── daily_summary.csv                          # 全日购电费、电量、损耗和首尾储电量
│   │       ├── dispatch.pdf                               # 调度图的PDF矢量版本
│   │       ├── dispatch.png                               # 输入功率、电价、购电、充放电和储量科研图
│   │       ├── dispatch.svg                               # 调度图的SVG矢量版本
│   │       ├── efficiency.pdf                             # 效率对比图的PDF矢量版本
│   │       ├── efficiency.png                             # 效率情景成本与储电轨迹对比图
│   │       ├── efficiency.svg                             # 效率对比图的SVG矢量版本
│   │       ├── efficiency_comparison.csv                  # 四种效率情景的成本、能量与调度指标对比
│   │       ├── report.html                                # 可展开查看完整输入、输出、对比与验证的报告
│   │       ├── result1.csv                                # 正式主结果；144时段输入与G/C/D/E/W/u、SOC、费用
│   │       ├── summary.json                               # 主模型汇总指标的JSON副本
│   │       ├── table1_purchase.csv                        # 题目指定六个10分钟区间的购电量
│   │       ├── table2_storage.csv                         # 题目指定六个4小时区间的充电量与放电量
│   │       ├── active_constraints.csv                     # 36组×144时段的SOC上下界及充放电上限活跃标记
│   │       ├── analysis_summary.json                      # 新版完整分析汇总、数值设置和经济机制指标
│   │       ├── arbitrage_thresholds.csv                   # 四效率口径×144时段的未来价格阈值和盈利时段数
│   │       ├── baseline_comparison.csv                    # No-ESS、PV-only、Full三种嵌套基准费用与电量
│   │       ├── bottleneck_analysis.pdf                    # 资源瓶颈分析图的PDF矢量版本
│   │       ├── bottleneck_analysis.png                    # 容量及独立充放电功率的三步长日价值对照图
│   │       ├── bottleneck_analysis.svg                    # 资源瓶颈分析图的SVG矢量版本
│   │       ├── bottleneck_values.csv                      # 114次独立容量/充电/放电放宽的单位日价值与活跃时段
│   │       ├── incremental_benefits.csv                   # 两步增量收益及总节约；不作唯一因果归因
│   │       ├── lp_diagnosis.csv                           # LP松弛目标、整数间隙、分数模式与同时充放电统计
│   │       ├── marginal_analysis.pdf                      # 边际机制分析图的PDF矢量版本
│   │       ├── marginal_analysis.png                      # 局部阈值、嵌套基准费用与负荷/光伏敏感性科研图
│   │       ├── marginal_analysis.svg                      # 边际机制分析图的SVG矢量版本
│   │       ├── marginal_report.html                       # 边际价值完整报告、36情景表、局部阈值及CSV入口
│   │       ├── marginal_rhs_validation.csv                # 288个母线/状态等式的双侧微扰与影子价格区间检查
│   │       ├── marginal_values.csv                        # 5184行局部μ/λ、充停放阈值、实际动作及模式限制
│   │       ├── normalized_sensitivity.csv                 # 四种效率口径下负荷/光伏的8项归一化成本敏感度
│   │       └── sensitivity_scenarios.csv                  # 36情景费用、电量、边界、资源价值和调度变化汇总
│   └── q1/                                                # 第一问当前求解、验收及历史审查的原始记录
│       └── raw/                                           # 原始解、情景轨迹、运行与检查证据；全部使用英文路径
│           ├── delivery_acceptance.json                   # 交付文件、编码、链接及界面检查记录
│           ├── docs_organization_manifest.json            # 文档分类移动清单与整理前后哈希验收
│           ├── q1_compact_review_acceptance.json          # 历史精简稿审查的验收记录
│           ├── q1_compact_review_evidence.json            # 历史精简稿审查的数值实验与完整轨迹
│           ├── q1_compact_review_run.json                 # 历史精简稿审查的执行摘要
│           ├── run_manifest.json                          # 本次运行命令、软件版本及输入/模型/代码/输出哈希
│           ├── schedule_eta085.csv                        # 单程0.85效率情景的144时段轨迹
│           ├── schedule_eta095.csv                        # 单程0.95效率情景的144时段轨迹
│           ├── schedule_main.csv                          # 主模型144时段全量输入与决策变量
│           ├── schedule_roundtrip090.csv                  # 对称往返0.9效率情景的144时段轨迹
│           ├── solution_eta085.json                       # 双单程0.85效率情景的原始解
│           ├── solution_eta095.json                       # 双单程0.95效率情景的原始解
│           ├── solution_main.json                         # 主模型双单程0.9效率的原始解与最优性证书
│           ├── solution_roundtrip090.json                 # 对称往返0.9效率情景的原始解
│           ├── tests.json                                 # 解析算例、压力测试与篡改拦截测试结果
│           ├── validation.json                            # 四情景物理、最优性及CSV回读检查指标
│           ├── analysis_schedules.csv                     # 36组×144时段的扰动输入与G/C/D/E/W/u完整轨迹
│           ├── analysis_solutions.json                    # 基准、松弛、36组模式及114个资源放宽MILP原始解
│           ├── analysis_tests.json                        # 7组新增分析测试的实际运行结果
│           ├── analysis_validation.json                   # 分析物理/最优性、LP与288方向微扰、CSV回读证据
│           ├── temporary_plan_formula_check.json          # 旧方案修订公式的验算证据
│           ├── temporary_plan_review_acceptance.json      # 旧临时方案审查验收结果
│           ├── temporary_plan_review_evidence.json        # 旧临时方案的对照数值实验
│           └── temporary_plan_review_run.json             # 旧临时方案审查的运行记录
├── src/                                                   # 按题号组织的求解、导出、报告与测试源码
│   ├── q1/                                                # 当前第一问实现与保留的历史审查程序
│   │   ├── export.py                                      # 正式CSV暂存写入、关闭回读与一致性校验
│   │   ├── model.py                                       # 输入标准化、共享MILP/LP约束与独立物理/最优性复核
│   │   ├── report.py                                      # 结果说明、输入输出HTML和科研图表生成
│   │   ├── requirements.txt                               # 锁定NumPy、SciPy、openpyxl、Matplotlib版本
│   │   ├── review_compact_q1.py                           # 历史精简稿审查实验；不是当前正式求解器
│   │   ├── run.py                                         # 正式入口；主MILP、CSV、完整边际及稳健性分析和报告
│   │   ├── test_q1.py                                     # 解析解、异常输入、压力与CSV篡改验收测试
│   │   ├── analysis.py                                    # LP诊断、嵌套基准、边际量、114次放宽与36情景分析
│   │   ├── analysis_report.py                             # 边际价值科研图、HTML报告与经济解释生成
│   │   └── test_analysis.py                               # 新增7组解析、符号、36情景、114次放宽与导出测试
│   └── 问题1/                                             # 旧临时方案审查源码；历史中文目录保留
│       └── review_temporary_plan.py                       # 旧临时方案的独立数值对照与漏洞验证
├── CUMCMThesis/                                           # 全国大学生数学建模竞赛LaTeX模板及示例
│   ├── figures/                                           # 模板示例与说明使用的配套图片资源
│   │   ├── cat.pdf                                        # 模板附带的插图/说明资源
│   │   ├── f1.png                                         # 模板附带的插图/说明资源
│   │   ├── gongzhonghao.jpg                               # 模板附带的插图/说明资源
│   │   ├── gongzhonghao2.png                              # 模板附带的插图/说明资源
│   │   ├── smokeblk.pdf                                   # 模板附带的插图/说明资源
│   │   └── upload.png                                     # 模板附带的插图/说明资源
│   ├── .gitignore                                         # 模板项目的版本控制忽略规则
│   ├── README.md                                          # 论文模板的用法、示例和更新说明
│   ├── cumcm2026.sty                                      # 2026样式补充；标题、表格、代码及AI声明等排版
│   ├── cumcmthesis.cls                                    # 竞赛论文LaTeX文档类
│   ├── example-1.png                                      # 模板说明附带的示例预览图片
│   ├── example.pdf                                        # 模板示例编译出的PDF
│   └── example.tex                                        # 模板示例源文件；当前不是本题最终论文
├── .agents/                                               # 项目实际技能所在目录
│   └── skills/                                            # 360个技能包及各自SKILL.md、脚本和参考资料；按目录汇总
├── SKILLS/                                                # 28份技能来源与用途说明TXT；辅助资料按目录汇总
└── .idea/                                                 # PyCharm项目与工作区配置；本机辅助配置按目录汇总
```

### 常用入口

- [数学建模开发规范](数学建模开发规范.md)
- [第一问文档分类导航](docs/1/README.md)
- [当前最终模型](docs/1/final/第一问_MILP_边际价值强化版.md)
- [运行说明与CSV字段](docs/1/deliverables/q1_run_guide.md)
- [输入CSV](inputs/q1/processed/timeseries.csv) · [完整输出CSV](outputs/processed/q1/result1.csv) · [结果摘要](docs/1/deliverables/q1_results.md)
- [新版边际分析报告](outputs/processed/q1/marginal_report.html) · [36组情景CSV](outputs/processed/q1/sensitivity_scenarios.csv)
- [任务变更历史](docs/CHANGE_HISTORY.md)

在项目根目录运行第一问：

```sh
uv run --with-requirements src/q1/requirements.txt python src/q1/run.py
```

按照开发规范，每次新增、移动或删除核心文件后，同步更新本目录树、对应注释及入口链接。目录树描述实际已有文件；历史审查、模板示例和已完成任务笔记均按其真实用途标注。

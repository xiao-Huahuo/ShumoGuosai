# README

本项目保存数学建模题目资料、模型文档、输入输出、求解代码和论文模板。正式入口为第一问 `src/q1/run.py` 和第二问数据诊断 `src/q2/run.py`，结果表格使用CSV。

### 项目目录树（持续维护）

下列目录树逐文件覆盖题目资料、模型、输入、结果、源码和论文模板。技能包、技能来源说明、本机IDE配置和不可变运行历史按目录汇总；Git内部对象、Python缓存与系统缓存不属于核心文件。所有列出的文件和文件夹均附用途说明。

```text
ShumoGuosai/  # 数学建模项目根目录；两问计算与全项目科研绘图集中管理
├── README.md  # 项目总览与核心目录树；文件变化后持续同步
├── AGENTS.md  # 代理执行规则、需求逐项验收及UTF-8要求
├── CLAUDE.md  # 项目协作与代码修改规则
├── 数学建模开发规范.md  # 建模、代码目录、结果审查、绘图及变更记录规范
├── .gitignore  # 忽略本地技能、IDE配置与技能来源目录
├── skills-lock.json  # 本地技能安装来源与版本锁定信息
├── docs/  # 题目资料、模型文档、使用说明和变更记录
│   ├── 1/  # 第一问文档；按最终、交付、中间、清理候选四类管理
│   │   ├── README.md  # 第一问逐文件分类说明与阅读导航
│   │   ├── final/  # 正式模型原稿；强化版为当前唯一执行依据，上一版保留追溯
│   │   │   ├── Q1最终优化模型-最终版.md  # 上一版MILP原稿；内容保留，当前执行强化版
│   │   │   └── 第一问_MILP_边际价值强化版.md  # 当前最新版；MILP、局部边际阈值、经济瓶颈与36组稳健性分析
│   │   ├── deliverables/  # 当前结果说明、复现文档和验收附件
│   │   │   ├── q1_implementation_acceptance.md  # 24条review验收、25项测试、P0–P3与假设及浏览器检查
│   │   │   ├── q1_results.md  # 正式计算结果、题目表1/表2及效率对比
│   │   │   ├── q1_run_guide.md  # 运行命令、输入输出路径、CSV字段和单位说明
│   │   │   ├── q1_source_line_traceability.csv  # 154个展示公式及5项行内判据到精确代码行、测试和运行证据
│   │   │   ├── q1_marginal_analysis.md  # 新版基准收益、边际机制、瓶颈及非预期敏感性趋势解释
│   │   │   ├── q1_code_review_resolution.csv  # 24条原review逐项处理、精确代码行、测试及当前运行证据
│   │   │   └── q1_paper_materials.md  # 第一问论文材料入口、题目逐项对应与本次整理验收
│   │   ├── intermediate/  # 历史模型与旧稿评审；不作为当前求解依据
│   │   │   ├── Q1_最终优化模型_结合comments.md  # 历史规范化能流、LP松弛与二级目标版本
│   │   │   ├── Q1_最终优化模型修订版_结合评审comments.md  # 历史LP路线的进一步修订稿
│   │   │   ├── Q1_精简修订版_公式兼容Obsidian.md  # 历史模型精简稿与Obsidian公式排版版本
│   │   │   ├── q1_compact_review_comments.md  # 当时精简稿的评审意见及实验说明
│   │   │   ├── 临时方案.md  # 早期方案；包含LP、KKT、对偶与敏感性分析
│   │   │   ├── 临时方案_严格审查报告.md  # 当时临时稿的审查意见与风险证据
│   │   │   ├── marginal_value_work/  # 强化版开发过程记录；完成后用于追溯
│   │   │   │   ├── notes.md  # 边际符号、分析范围、计算发现及限制记录
│   │   │   │   └── task_plan.md  # 强化版逐项实现计划与验收进度
│   │   │   └── code_review_work/  # 本轮review原件与修改前源码备份；不作为当前运行结果
│   │   │       ├── Q1_code_review_comments.csv  # 用户提供的24条审查意见原始CSV；其中XLSX建议被用户覆盖
│   │   │       └── pre_review_sources.tar.gz  # 本轮修改前源码和相关文档的备份；用于对照与追溯
│   │   └── cleanup_candidates/  # 已结束任务的过程笔记；候选清理但尚未删除
│   │       ├── notes.md  # 实现过程发现摘要；有效信息已进入交付文档
│   │       └── task_plan.md  # 已经全部完成的任务计划与过程记录
│   ├── CUMCM2026Problems/  # A至E题原题、随题附件和格式文件
│   │   ├── A题/  # A题原始题目资料
│   │   │   ├── 附件/  # A题随题提供的原始数据与附件
│   │   │   │   ├── 附件3/  # A题随题提供的结果模板目录
│   │   │   │   │   ├── result1.xlsx  # A题随题提供的result1结果模板；原件保留
│   │   │   │   │   ├── result2.xlsx  # A题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx  # A题随题提供的result3结果模板；原件保留
│   │   │   │   │   └── result4.xlsx  # A题随题提供的result4结果模板；原件保留
│   │   │   │   ├── 附件1.xlsx  # A题原始附件1数据/说明文件
│   │   │   │   └── 附件2.xlsx  # A题原始附件2数据/说明文件
│   │   │   └── A题.pdf  # A题原始题面PDF
│   │   ├── B题/  # B题原始题目资料
│   │   │   ├── 附件/  # B题随题提供的原始数据与附件
│   │   │   │   ├── 附件1.docx  # B题原始附件1数据/说明文件
│   │   │   │   └── 附件2.docx  # B题原始附件2数据/说明文件
│   │   │   └── B题.pdf  # B题原始题面PDF
│   │   ├── C题/  # C题原始题目资料
│   │   │   ├── 附件/  # C题随题提供的原始数据与附件
│   │   │   │   ├── 附件5/  # 原题结果模板；当前Q1按用户要求改用CSV交付
│   │   │   │   │   ├── result1.xlsx  # C题随题提供的result1结果模板；原件保留
│   │   │   │   │   ├── result2.xlsx  # C题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx  # C题随题提供的result3结果模板；原件保留
│   │   │   │   │   ├── result4-2.xlsx  # C题随题提供的result4-2结果模板；原件保留
│   │   │   │   │   └── result4-3.xlsx  # C题随题提供的result4-3结果模板；原件保留
│   │   │   │   ├── 附件1.xlsx  # 一天电价、负荷与光伏预测；当前Q1的原始数据来源
│   │   │   │   ├── 附件2.xlsx  # 2025年全年负荷与实际光伏数据；供后续问题使用
│   │   │   │   ├── 附件3.xlsx  # 不同发布时刻的未来24小时光伏预报；供后续问题使用
│   │   │   │   └── 附件4.xlsx  # 波动电价数据；供第四问使用
│   │   │   └── C题.pdf  # C题原始题面PDF
│   │   ├── D题/  # D题原始题目资料
│   │   │   ├── 附件/  # D题随题提供的原始数据与附件
│   │   │   │   ├── 附件2/  # D题随题提供的结果模板目录
│   │   │   │   │   ├── result1.xlsx  # D题随题提供的result1结果模板；原件保留
│   │   │   │   │   ├── result2.xlsx  # D题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx  # D题随题提供的result3结果模板；原件保留
│   │   │   │   │   └── result4.xlsx  # D题随题提供的result4结果模板；原件保留
│   │   │   │   └── 附件1.xlsx  # D题原始附件1数据/说明文件
│   │   │   └── D题.pdf  # D题原始题面PDF
│   │   ├── E题/  # E题原始题目资料
│   │   │   ├── 附件/  # E题随题提供的原始数据与附件
│   │   │   │   ├── 附件2/  # E题随题提供的结果模板目录
│   │   │   │   │   ├── result2.xlsx  # E题随题提供的result2结果模板；原件保留
│   │   │   │   │   ├── result3.xlsx  # E题随题提供的result3结果模板；原件保留
│   │   │   │   │   └── result4.xlsx  # E题随题提供的result4结果模板；原件保留
│   │   │   │   └── 附件1.xlsx  # E题原始附件1数据/说明文件
│   │   │   └── E题.pdf  # E题原始题面PDF
│   │   └── format2026.doc  # 随题提供的2026格式文件
│   ├── CHANGE_HISTORY.md  # 按现状、实施方案、完成状态记录每次任务
│   ├── C题.md  # C题题面转写、各问要求与储能参数附录
│   ├── 数学建模技能清单.md  # 本地技能分类、用途与选用参考
│   ├── 2/  # 第二问2.1阶段方案、运行、验收与过程证据
│   │   ├── dierwen1.md  # 第二问2.1数据预处理与时间序列诊断的指定执行方案
│   │   ├── notes.md  # 实施决策、算法依据、实算发现与限制
│   │   ├── task_plan.md  # 逐项实施与验收计划、修复记录
│   │   ├── implementation_acceptance.md  # 逐句验收、P0–P3、假设与实际界面检查
│   │   ├── run_guide.md  # 完整运行命令、CSV字段、模型接入与严格信息边界
│   │   └── verification.json  # 最终文件、哈希、链接、目录与实际浏览器验收记录
│   └── plots/  # 论文图与集中管理的逐项验收记录
│       ├── acceptance.md  # 18项需求、P0—P3、假设、数值与视觉验收
│       ├── migration_verification.json  # 原15图PNG字节一致、128个原文件不变和49项测试结果
│       ├── q1_tests.txt  # 迁移后Q1全部25项测试通过的完整日志
│       ├── q1_traceability_check.json  # 当前代码167条公式映射重新生成检查
│       ├── q2_tests.txt  # 迁移后Q2全部24项测试通过的完整日志
│       ├── q2_traceability_check.json  # 当前代码265条句子映射及集中绘图位置检查
│       ├── requirements_acceptance.csv  # 18条逐句需求到代码行与实际证据的对应
│       ├── ui_smoke.json  # 浏览器8图与23图加载、CSV下载和窄视口检查
│       └── verification.json  # 8图时序、单位、收益、设备解、格式与源码集中化验收
├── inputs/  # 按照题号保存原始输入和预处理输入
│   ├── q1/  # 第一问当前输入别名；随q1_current统一切换
│   │   ├── processed/  # 经过时间映射和单位换算的求解输入
│   │   │   ├── parameters.json  # 储能参数、四种效率情景和用户确认的计算口径
│   │   │   └── timeseries.csv  # 144时段输入；含右端点映射与kW转kWh结果
│   │   └── raw/  # 原始数据副本与来源追溯记录
│   │       ├── attachment1.csv  # 原附件时间、电价、负荷功率、光伏功率的CSV副本
│   │       ├── attachment1.xlsx  # C题附件1原始工作簿副本；仅用于读取输入
│   │       └── manifest.json  # 原始附件路径、副本路径和SHA-256
│   └── q2/  # 第二问当前输入别名；随q2_current统一切换
│       ├── processed/  # 规范化功率长表与诊断方法设置
│       │   ├── settings.json  # 算法、单位、截止时点及用户确认的信息边界
│       │   └── timeseries.csv  # 52560行连续右端点长表；原始kW逐值保留
│       └── raw/  # 附件2只读副本及来源记录
│           ├── attachment2.xlsx  # 附件2原始XLSX只读副本；不作为结果格式
│           └── manifest.json  # 附件来源与SHA-256
├── outputs/  # 按规范保存原始结果和整理后的交付结果
│   ├── processed/  # 面向阅读、论文及交付的整理结果
│   │   ├── q1/  # 第一问当前正式CSV、HTML与图表别名；无XLSX交付
│   │   │   ├── daily_summary.csv  # 全日购电费、电量、损耗和首尾储电量
│   │   │   ├── dispatch.pdf  # 调度图的PDF矢量版本；旧运行产物，后续不再生成
│   │   │   ├── dispatch.png  # 输入功率、电价、购电、充放电和储量科研图
│   │   │   ├── dispatch.svg  # 调度图的SVG矢量版本
│   │   │   ├── efficiency.pdf  # 效率对比图的PDF矢量版本；旧运行产物，后续不再生成
│   │   │   ├── efficiency.png  # 效率情景成本与储电轨迹对比图
│   │   │   ├── efficiency.svg  # 效率对比图的SVG矢量版本
│   │   │   ├── efficiency_comparison.csv  # 四种效率情景的成本、能量与调度指标对比
│   │   │   ├── report.html  # 可展开查看完整输入、输出、对比与验证的报告
│   │   │   ├── result1.csv  # 正式主结果；144时段输入与G/C/D/E/W/u、SOC、费用
│   │   │   ├── summary.json  # 主模型汇总指标的JSON副本
│   │   │   ├── table1_purchase.csv  # 题目指定六个10分钟区间的购电量
│   │   │   ├── table2_storage.csv  # 题目指定六个4小时区间的充电量与放电量
│   │   │   ├── active_constraints.csv  # 36组×144时段的SOC上下界及充放电上限活跃标记
│   │   │   ├── analysis_summary.json  # 新版完整分析汇总、数值设置和经济机制指标
│   │   │   ├── arbitrage_thresholds.csv  # 四效率口径×144时段的未来价格阈值和盈利时段数
│   │   │   ├── baseline_comparison.csv  # No-ESS、PV-only、Full三种嵌套基准费用与电量
│   │   │   ├── bottleneck_analysis.pdf  # 资源瓶颈分析图的PDF矢量版本；旧运行产物，后续不再生成
│   │   │   ├── bottleneck_analysis.png  # 储能上下限及独立充放功率的三步长单位日价值图
│   │   │   ├── bottleneck_analysis.svg  # 资源瓶颈分析图的SVG矢量版本
│   │   │   ├── bottleneck_values.csv  # 36情景×4边界×3步长共432次放宽、稳定性与数值瓶颈
│   │   │   ├── incremental_benefits.csv  # 两步增量收益及总节约；不作唯一因果归因
│   │   │   ├── lp_diagnosis.csv  # LP松弛目标、整数间隙、分数模式与同时充放电统计
│   │   │   ├── marginal_analysis.pdf  # 边际机制分析图的PDF矢量版本；旧运行产物，后续不再生成
│   │   │   ├── marginal_analysis.png  # 局部阈值、嵌套基准费用与负荷/光伏敏感性科研图
│   │   │   ├── marginal_analysis.svg  # 边际机制分析图的SVG矢量版本
│   │   │   ├── marginal_report.html  # 边际价值完整报告、36情景表、局部阈值及CSV入口
│   │   │   ├── marginal_rhs_validation.csv  # 固定模式LP的288个母线/状态RHS双侧扰动与影子价检查
│   │   │   ├── marginal_values.csv  # 5184行局部μ/λ、充停放阈值、实际动作及模式限制
│   │   │   ├── normalized_sensitivity.csv  # 四种效率口径下负荷/光伏的8项归一化成本敏感度
│   │   │   ├── sensitivity_scenarios.csv  # 36情景费用、电量、边界、资源价值和调度变化汇总
│   │   │   └── milp_rhs_validation.csv  # 原MILP的288个RHS双侧共576次重求与固定影子价对照
│   │   ├── q1_paper/  # 第一问论文材料；目录按来源运行代与整理代码哈希标识
│   │   │   ├── run-ie6fkatf-d9b1d24a/  # 本次论文材料：144规划、题目表1/表2、结果比较、图及说明
│   │   │   │   ├── README.md  # 论文材料取用顺序、可引用结果段落、口径与局限
│   │   │   │   ├── baseline_comparison_paper.csv  # 嵌套基准与节约比较；结果分析或稳健性分析
│   │   │   │   ├── bottleneck_analysis.png  # 四类边界放宽的单位日价值；论文插图
│   │   │   │   ├── bottleneck_analysis.svg  # 四类边界放宽的单位日价值；论文插图
│   │   │   │   ├── boundary_values_paper.csv  # 主方案四类边界的三步长日价值；边际价值分析（可选）
│   │   │   │   ├── daily_indicators.csv  # 主方案全日指标；摘要、结果分析
│   │   │   │   ├── dispatch.png  # 主方案调度与储电轨迹；论文插图
│   │   │   │   ├── dispatch.svg  # 主方案调度与储电轨迹；论文插图
│   │   │   │   ├── efficiency.png  # 效率口径对费用和储电轨迹的影响；论文插图
│   │   │   │   ├── efficiency.svg  # 效率口径对费用和储电轨迹的影响；论文插图
│   │   │   │   ├── efficiency_comparison_paper.csv  # 效率口径比较；结果分析或稳健性分析
│   │   │   │   ├── index.html  # 论文表格及四张图的浏览器预览；144行可展开滚动
│   │   │   │   ├── marginal_analysis.png  # 基准比较、局部阈值及输入敏感性；论文插图
│   │   │   │   ├── marginal_analysis.svg  # 基准比较、局部阈值及输入敏感性；论文插图
│   │   │   │   ├── materials_index.csv  # 全部CSV/PNG/SVG的标题、行数、论文用途和图注
│   │   │   │   ├── model_parameters.csv  # 模型参数与计算口径；符号说明、参数设置
│   │   │   │   ├── provenance.json  # 来源62项哈希、整理代码和材料哈希及核验结果
│   │   │   │   ├── sensitivity_36_paper.csv  # 36组效率、负荷及光伏情景；稳健性分析或附录（可选）
│   │   │   │   ├── table1_purchase_paper.csv  # 表1 微网指定时段及全天购电结果；题目要求：论文正文
│   │   │   │   ├── table2_storage_paper.csv  # 表2 储能分区间充放电量及首尾储电量；题目要求：论文正文
│   │   │   │   └── table_144_dispatch.csv  # 完整最优方案：144个10分钟时段；附录或完整结果附件
│   │   │   └── run-ie6fkatf-d9b1d24a.zip  # 本次21文件论文材料压缩包；可整体分享或解压使用
│   │   ├── q2/  # 第二问清洗数据、结构诊断CSV、报告与科研图
│   │   │   ├── evaluation_status.csv  # 后续实际预测和调度指标未计算的明确状态；非零值
│   │   │   ├── figures/  # 11类分析图，每类同时导出PNG和SVG
│   │   │   │   ├── acf_pacf.png  # 两类功率ACF/PACF的短期、日、周多尺度视图；PNG
│   │   │   │   ├── acf_pacf.svg  # 两类功率ACF/PACF的短期、日、周多尺度视图；SVG
│   │   │   │   ├── annual_heatmaps.png  # 负荷/光伏365×144全年日期时间热力图；PNG
│   │   │   │   ├── annual_heatmaps.svg  # 负荷/光伏365×144全年日期时间热力图；SVG
│   │   │   │   ├── daily_peaks.png  # 全年逐日峰值及峰值时刻迁移；PNG
│   │   │   │   ├── daily_peaks.svg  # 全年逐日峰值及峰值时刻迁移；SVG
│   │   │   │   ├── monthly_profiles.png  # 三类功率12个月平均日曲线；PNG
│   │   │   │   ├── monthly_profiles.svg  # 三类功率12个月平均日曲线；SVG
│   │   │   │   ├── monthly_stability.png  # 月度周期相关、日峰谷、波动与水平；PNG
│   │   │   │   ├── monthly_stability.svg  # 月度周期相关、日峰谷、波动与水平；SVG
│   │   │   │   ├── seasonal_moments.png  # 四种季节处理后的月均值和波动；PNG
│   │   │   │   ├── seasonal_moments.svg  # 四种季节处理后的月均值和波动；SVG
│   │   │   │   ├── spectra.png  # 原始与日曲线残差频谱及日/周位置；PNG
│   │   │   │   ├── spectra.svg  # 原始与日曲线残差频谱及日/周位置；SVG
│   │   │   │   ├── timeseries_30d.png  # 连续30天三类原始功率曲线；PNG
│   │   │   │   ├── timeseries_30d.svg  # 连续30天三类原始功率曲线；SVG
│   │   │   │   ├── timeseries_7d.png  # 连续7天三类原始功率曲线；PNG
│   │   │   │   ├── timeseries_7d.svg  # 连续7天三类原始功率曲线；SVG
│   │   │   │   ├── weekday_profiles.png  # 负荷/光伏星期一至星期日平均日曲线；PNG
│   │   │   │   ├── weekday_profiles.svg  # 负荷/光伏星期一至星期日平均日曲线；SVG
│   │   │   │   ├── weekday_weekend.png  # 周一至周五与周末平均日曲线对照；PNG
│   │   │   │   └── weekday_weekend.svg  # 周一至周五与周末平均日曲线对照；SVG
│   │   │   ├── full_year_acf_pacf.csv  # 全年事后诊断；0至2016阶FFT自相关与Burg偏自相关
│   │   │   ├── full_year_daily_statistics.csv  # 全年事后诊断；每日峰谷、波动、峰值时段、并列峰与零值
│   │   │   ├── full_year_lag_correlations.csv  # 全年事后诊断；六种关键滞后的原始/去平均日曲线相关
│   │   │   ├── full_year_monthly_stability.csv  # 全年事后诊断；月内日/周相关、均值、波动和日峰谷幅度
│   │   │   ├── full_year_profiles.csv  # 全年事后诊断；月份、星期及工作日/周末平均日曲线与n/std
│   │   │   ├── full_year_pv_zero_profile.csv  # 全年事后诊断；各槽位光伏零值数和比例，不推定固定夜间
│   │   │   ├── full_year_spectral_targets.csv  # 全年事后诊断；日/周目标频点与邻点、局部峰及Parseval验证
│   │   │   ├── full_year_spectrum.csv  # 全年事后诊断；原始与日曲线残差的全正频率功率谱
│   │   │   ├── full_year_stationarity_tests.csv  # 全年事后诊断；32条ADF/KPSS检验、c/ct、临界值与p值界限
│   │   │   ├── full_year_summary.csv  # 全年事后诊断；三类功率样本量、均值、波动、极值与零值
│   │   │   ├── full_year_transformed_monthly_moments.csv  # 全年事后诊断；四种变换的月均值、标准差和样本量
│   │   │   ├── full_year_transformed_series.csv  # 全年事后诊断；原始、日差分、周差分、日后周差分的实际序列
│   │   │   ├── initial_history_acf_pacf.csv  # 首次预测前4463点诊断；0至2016阶FFT自相关与Burg偏自相关
│   │   │   ├── initial_history_daily_statistics.csv  # 首次预测前4463点诊断；每日峰谷、波动、峰值时段、并列峰与零值
│   │   │   ├── initial_history_lag_correlations.csv  # 首次预测前4463点诊断；六种关键滞后的原始/去平均日曲线相关
│   │   │   ├── initial_history_monthly_stability.csv  # 首次预测前4463点诊断；月内日/周相关、均值、波动和日峰谷幅度
│   │   │   ├── initial_history_profiles.csv  # 首次预测前4463点诊断；月份、星期及工作日/周末平均日曲线与n/std
│   │   │   ├── initial_history_pv_zero_profile.csv  # 首次预测前4463点诊断；各槽位光伏零值数和比例，不推定固定夜间
│   │   │   ├── initial_history_spectral_targets.csv  # 首次预测前4463点诊断；日/周目标频点与邻点、局部峰及Parseval验证
│   │   │   ├── initial_history_spectrum.csv  # 首次预测前4463点诊断；原始与日曲线残差的全正频率功率谱
│   │   │   ├── initial_history_stationarity_tests.csv  # 首次预测前4463点诊断；32条ADF/KPSS检验、c/ct、临界值与p值界限
│   │   │   ├── initial_history_summary.csv  # 首次预测前4463点诊断；三类功率样本量、均值、波动、极值与零值
│   │   │   ├── initial_history_transformed_monthly_moments.csv  # 首次预测前4463点诊断；四种变换的月均值、标准差和样本量
│   │   │   ├── initial_history_transformed_series.csv  # 首次预测前4463点诊断；原始、日差分、周差分、日后周差分的实际序列
│   │   │   ├── jump_context.csv  # 29818个局部转折点的前后与历史同类上下文，保留不删除
│   │   │   ├── model_candidates.csv  # 仅依据首次回测前可见历史形成候选与条件
│   │   │   ├── quality_checks.csv  # 原始核验清单的报告下载副本
│   │   │   ├── report.html  # 可查看11张图、完整统计、滚动切分与下载的报告
│   │   │   ├── results.md  # 实算结论、星期异常特征、候选依据和阶段边界
│   │   │   ├── rolling_folds.csv  # 334日严格timestamp小于0:00的滚动切分与144段目标
│   │   │   ├── source_traceability.csv  # 254非空源行、265句到精确函数/测试行和产物的映射
│   │   │   └── timeseries.csv  # 便于报告下载的清洗后长表副本，52560行
│   │   └── figures/  # 集中图集；新论文图与项目原图导航
│   │       ├── index.html  # 全项目23组图预览与脚本入口
│   │       └── q1/  # 第一问8张新论文图、12份数据CSV及图目CSV
│   │           ├── 01_data_features.png  # 负荷、光伏与电价的日内变化特征；可选：背景说明；300dpi
│   │           ├── 01_data_features.svg  # 负荷、光伏与电价的日内变化特征；可选：背景说明；矢量路径
│   │           ├── 02_optimal_dispatch.png  # 最优购电计划与储能运行轨迹；必选：核心结果；300dpi
│   │           ├── 02_optimal_dispatch.svg  # 最优购电计划与储能运行轨迹；必选：核心结果；矢量路径
│   │           ├── 03_cost_waterfall.png  # 逐步放宽调度限制的购电费用变化；建议：结果解释；300dpi
│   │           ├── 03_cost_waterfall.svg  # 逐步放宽调度限制的购电费用变化；建议：结果解释；矢量路径
│   │           ├── 04_device_sensitivity.png  # 设备边界与最优购电费用；可选：瓶颈分析；300dpi
│   │           ├── 04_device_sensitivity.svg  # 设备边界与最优购电费用；可选：瓶颈分析；矢量路径
│   │           ├── 05_joint_contour.png  # 储电上限与共同功率上限的联合敏感性；可选：联合敏感性；300dpi
│   │           ├── 05_joint_contour.svg  # 储电上限与共同功率上限的联合敏感性；可选：联合敏感性；矢量路径
│   │           ├── 06_efficiency.png  # 储能效率变化下的费用与运行轨迹；可选：效率稳健性；300dpi
│   │           ├── 06_efficiency.svg  # 储能效率变化下的费用与运行轨迹；可选：效率稳健性；矢量路径
│   │           ├── 07_input_sensitivity.png  # 负荷与光伏输入扰动下的购电费用；可选：输入稳健性；300dpi
│   │           ├── 07_input_sensitivity.svg  # 负荷与光伏输入扰动下的购电费用；可选：输入稳健性；矢量路径
│   │           ├── 08_fixed_mode_diagnostic.png  # 固定模式边际价格的局部诊断；备查：局部诊断，不建议放正文；300dpi
│   │           ├── 08_fixed_mode_diagnostic.svg  # 固定模式边际价格的局部诊断；备查：局部诊断，不建议放正文；矢量路径
│   │           ├── baseline_metrics.csv  # 三种嵌套调度方案的全日指标
│   │           ├── cost_waterfall.csv  # 五段瀑布总量、增量与柱底费用
│   │           ├── data_features.csv  # 144段负荷、光伏、价格与富余光伏绘图数据
│   │           ├── device_joint_grid.csv  # 110个真实联合MILP网格点
│   │           ├── device_one_dimensional.csv  # 三条设备单变量曲线的36个数据点
│   │           ├── dispatch_power.csv  # 144段无储能及最优购电、充放电功率和实际状态
│   │           ├── efficiency_metrics.csv  # 四种效率口径的费用与能量指标
│   │           ├── efficiency_storage.csv  # 四种效率下各145个储电量点
│   │           ├── figure_index.csv  # 8张新图的必要性、脚本、CSV和准确图注
│   │           ├── fixed_mode_marginals.csv  # 主方案144个固定模式局部边际诊断
│   │           ├── index.html  # 按必选、建议、可选和备查排列的图集
│   │           ├── input_sensitivity.csv  # 主效率下9组负荷与光伏扰动
│   │           ├── milp_rhs_checks.csv  # 原MILP双侧扰动与固定影子价的288条对照
│   │           ├── provenance.json  # 新图源码、原运行来源、设备扫描与文件哈希
│   │           └── storage_145.csv  # 含日初的145个储电量边界点
│   ├── q1/  # 第一问当前求解、验收及历史审查的原始记录
│   │   ├── raw/  # 当前运行原始记录别名；历史review记录明确标注为历史
│   │   │   ├── q1_compact_review_acceptance.json  # 历史精简稿审查的验收记录
│   │   │   ├── q1_compact_review_evidence.json  # 历史精简稿审查的数值实验与完整轨迹
│   │   │   ├── q1_compact_review_run.json  # 历史精简稿审查的执行摘要
│   │   │   ├── run_manifest.json  # 本次运行命令、软件版本及输入/模型/代码/输出哈希
│   │   │   ├── schedule_eta085.csv  # 单程0.85效率情景的144时段轨迹
│   │   │   ├── schedule_eta095.csv  # 单程0.95效率情景的144时段轨迹
│   │   │   ├── schedule_main.csv  # 主模型144时段全量输入与决策变量
│   │   │   ├── schedule_roundtrip090.csv  # 对称往返0.9效率情景的144时段轨迹
│   │   │   ├── solution_eta085.json  # 双单程0.85效率情景的原始解
│   │   │   ├── solution_eta095.json  # 双单程0.95效率情景的原始解
│   │   │   ├── solution_main.json  # 主模型双单程0.9效率的原始解与最优性证书
│   │   │   ├── solution_roundtrip090.json  # 对称往返0.9效率情景的原始解
│   │   │   ├── tests.json  # 当前代码测试命令、退出状态与完整日志；独立子进程执行
│   │   │   ├── validation.json  # 四情景物理、最优性及CSV回读检查指标
│   │   │   ├── analysis_schedules.csv  # 36组×144时段的扰动输入与G/C/D/E/W/u完整轨迹
│   │   │   ├── analysis_solutions.json  # 36情景、基准、松弛、432次边界放宽及576次原MILP扰动解
│   │   │   ├── analysis_validation.json  # 全分析物理/最优性、双侧微扰及CSV回读证据
│   │   │   ├── temporary_plan_review_acceptance.json  # 旧临时方案审查验收结果
│   │   │   ├── temporary_plan_review_evidence.json  # 旧临时方案的对照数值实验
│   │   │   ├── temporary_plan_review_run.json  # 旧临时方案审查的运行记录
│   │   │   ├── figure_status.json  # 本次绘图成功、跳过或失败状态；失败不阻断正确CSV
│   │   │   ├── test_log.txt  # 当前代码25项测试的完整输出和故障注入记录
│   │   │   └── traceability_validation.json  # 154展示公式与5关键行内判据的覆盖、精确行锚点和源文哈希
│   │   └── figure_analysis/  # 绘图所需设备敏感性实算；按输入与源码哈希复用缓存
│   │       └── b6fbe67e925a/  # 本次133个不同参数点的已验收计算数据
│   │           ├── joint_grid.csv  # 110个储电上限与共同功率网格点的费用
│   │           ├── manifest.json  # 扫描范围、明示假设、来源哈希及回读验收
│   │           ├── one_dimensional.csv  # 三条单变量扫描共36行，包含基准及加100点
│   │           ├── solutions.npz  # 全部133个原始G/C/D/E/W/u解的压缩数组
│   │           └── solver_checks.csv  # 133个不同参数点、最优目标、Gap及物理残差
│   ├── .q1-runs/  # 保留当前、上一完整运行代及旧迁移验收目录；按目录汇总
│   ├── q1_current/  # 当前完整运行代的原子指针；数据在标准目录别名下逐文件列出
│   ├── .q2-runs/  # 保留当前与上一完整运行代；更早记录压缩归档至history
│   ├── q2/  # 第二问当前原始运行与验收结果
│   │   └── raw/  # 当前完整生成代原始记录别名
│   │       ├── figure_manifest.json  # 11张科研图的配套CSV、字体、分辨率和范围
│   │       ├── quality_checks.csv  # 结构、日期、时段、数值和物理一致性核验
│   │       ├── run_manifest.json  # 原始附件、方案、源码、软件版本与全部产物哈希
│   │       ├── test_results.txt  # 24项当前源码测试与真实产物回读的完整日志
│   │       └── validation.json  # CSV回读、数值恒等式和逐句覆盖机器验收
│   ├── q2_current/  # 第二问当前完整运行代原子指针；正式路径下逐文件列出
│   └── history/  # 已清理运行代的轻量追溯记录和逐文件清理验收
│       ├── run_records_20260911.tar.gz  # 59份旧运行清单、配置、验收及日志的压缩归档
│       ├── cleanup_20260911.csv  # 429个清理文件的原路径、处理方式、大小与SHA-256
│       └── cleanup_20260911.json  # 保留范围、清理前后体积及完整性检查结果
├── src/  # 按题号组织的求解、导出、报告与测试源码
│   ├── q1/  # 当前第一问实现与保留的历史审查程序
│   │   ├── export.py  # CSV导出和关闭回读；逐行、六区间、日汇总与单位容差校验
│   │   ├── model.py  # 输入标准化、共享MILP/LP约束与独立物理/最优性复核
│   │   ├── report.py  # 第一问HTML和文字报告；绘图委托src/plots/q1_legacy.py
│   │   ├── requirements.txt  # 锁定NumPy、SciPy、openpyxl、Matplotlib版本
│   │   ├── review_compact_q1.py  # 历史精简稿审查实验；不是当前正式求解器
│   │   ├── run.py  # 正式入口；完整暂存求解、CSV/分析/报告及测试后统一发布
│   │   ├── test_q1.py  # 解析解、异常输入、压力与CSV篡改验收测试
│   │   ├── analysis.py  # LP/基准/边际、36情景432次边界放宽及576次原MILP扰动
│   │   ├── analysis_report.py  # 边际分析文字和HTML报告；绘图委托集中模块
│   │   ├── test_analysis.py  # 7项分析测试：解析符号、36情景、432次放宽及CSV检查
│   │   ├── golden_main.json  # 修改前官方输入SHA及主目标基线；不固定不唯一的调度
│   │   ├── pipeline.py  # 测试门禁、可选绘图隔离及整代结果原子发布
│   │   ├── test_review.py  # 本轮10项回归：新解、效率、PV来源、边际与失败发布
│   │   ├── traceability.py  # 公式、代码语句、测试和本代证据精确映射与验证
│   │   ├── prepare_paper_materials.py  # 从已验收Q1结果生成中文CSV论文表、图表材料包并独立核验
│   │   └── device_sensitivity.py  # 133个不同设备参数点的MILP实算、压缩原解与回读验收
│   ├── 问题1/  # 旧临时方案审查源码；历史中文目录保留
│   │   └── review_temporary_plan.py  # 旧临时方案的独立数值对照与漏洞验证
│   ├── q2/  # 第二问2.1阶段完整实现与测试
│   │   ├── backtest.py  # 严格滚动预测接口、三类预测指标和真实调度计费评价
│   │   ├── data.py  # 附件2核验、右端点长表、严格历史和突变上下文
│   │   ├── diagnostics.py  # 描述、2016阶相关、频谱、月度稳定性及ADF/KPSS
│   │   ├── figures.py  # 第二问原调用接口与LABELS兼容，绘图委托src/plots/q2.py
│   │   ├── report.py  # 基于历史的候选依据、实算解释与HTML报告
│   │   ├── requirements.txt  # 锁定第二问科学计算与绘图依赖版本
│   │   ├── run.py  # 全流程入口；暂存、数值回读、测试、统一结果切换
│   │   ├── test_q2.py  # 24项原始值、防前视、手算、频谱、假设与发布验收
│   │   └── traceability.py  # 原方案逐行逐句到源码、测试和运行证据的映射
│   └── plots/  # 全部项目自写绘图代码的唯一维护目录；两问原入口保持兼容
│       ├── README.md  # 科研配色、必要性分类、统一命令和脚本职责说明
│       ├── catalog.py  # 生成全项目23组图清单与总图集
│       ├── common.py  # 中文字体、语义配色、费用色阶及300dpi PNG和SVG导出
│       ├── figure_registry.csv  # 23组图的脚本、数据、PNG/SVG位置和必要性
│       ├── q1_legacy.py  # 第一问原4组报告图的集中实现，外观保持一致
│       ├── q1_paper.py  # 第一问8张论文图、配套CSV和按必要性排序的图集
│       ├── q2.py  # 第二问原11张数据诊断图的集中实现
│       ├── replot_existing.py  # 从已验收CSV和JSON重绘Q1或Q2原有图
│       ├── run.py  # 统一命令，分别使用两问固定依赖环境
│       └── verify.py  # 144/145时序、单位、收益、设备解、图形格式和集中化验收
├── CUMCMThesis/  # 全国大学生数学建模竞赛LaTeX模板及示例
│   ├── figures/  # 模板示例与说明使用的配套图片资源
│   │   ├── cat.pdf  # 模板附带的插图/说明资源
│   │   ├── f1.png  # 模板附带的插图/说明资源
│   │   ├── gongzhonghao.jpg  # 模板附带的插图/说明资源
│   │   ├── gongzhonghao2.png  # 模板附带的插图/说明资源
│   │   ├── smokeblk.pdf  # 模板附带的插图/说明资源
│   │   └── upload.png  # 模板附带的插图/说明资源
│   ├── .gitignore  # 模板项目的版本控制忽略规则
│   ├── README.md  # 论文模板的用法、示例和更新说明
│   ├── cumcm2026.sty  # 2026样式补充；标题、表格、代码及AI声明等排版
│   ├── cumcmthesis.cls  # 竞赛论文LaTeX文档类
│   ├── example-1.png  # 模板说明附带的示例预览图片
│   ├── example.pdf  # 模板示例编译出的PDF
│   └── example.tex  # 模板示例源文件；当前不是本题最终论文
├── .agents/  # 项目实际技能所在目录
│   └── skills/  # 360个技能包及各自SKILL.md、脚本和参考资料；按目录汇总
├── SKILLS/  # 28份技能来源与用途说明TXT；辅助资料按目录汇总
├── .idea/  # PyCharm项目与工作区配置；本机辅助配置按目录汇总
└── TASK_STATE.md  # 当前绘图集中管理完成状态与此前Q1/Q2任务追溯
```

运行结果先在 `outputs/.q1-runs/` 中完整生成，全部数值检查和当前代码测试通过后，单次切换 `outputs/q1_current`。表格仅用CSV；HTML提供浏览器查看入口。

### 常用入口

- [第一问论文新图：必选／建议／可选／备查](outputs/processed/figures/q1/index.html)
- [全部绘图脚本集中管理](src/plots/README.md) · [23组图清单CSV](src/plots/figure_registry.csv) · [总图集](outputs/processed/figures/index.html)

- [数学建模开发规范](数学建模开发规范.md)
- [第一问文档分类导航](docs/1/README.md)
- [第一问论文材料包](docs/1/deliverables/q1_paper_materials.md)
- [当前最终模型](docs/1/final/第一问_MILP_边际价值强化版.md)
- [运行说明与CSV字段](docs/1/deliverables/q1_run_guide.md)
- [输入CSV](inputs/q1/processed/timeseries.csv) · [完整输出CSV](outputs/processed/q1/result1.csv) · [结果摘要](docs/1/deliverables/q1_results.md)
- [新版边际分析报告](outputs/processed/q1/marginal_report.html) · [36组情景CSV](outputs/processed/q1/sensitivity_scenarios.csv)
- [24条review处理CSV](docs/1/deliverables/q1_code_review_resolution.csv) · [本轮验收报告](docs/1/deliverables/q1_implementation_acceptance.md)
- [任务变更历史](docs/CHANGE_HISTORY.md)

在项目根目录运行第一问：

```sh
uv run --with-requirements src/q1/requirements.txt python src/q1/run.py
```

在项目根目录运行第二问数据清洗与分析：

```sh
uv run --with-requirements src/q2/requirements.txt python src/q2/run.py
```

第二问入口：[方案](docs/2/dierwen1.md) · [运行说明](docs/2/run_guide.md) · [分析报告与11张图](outputs/processed/q2/report.html) · [清洗后CSV](inputs/q2/processed/timeseries.csv) · [逐句验收](docs/2/implementation_acceptance.md)。第二问同样在全部检查通过后统一切换 `outputs/q2_current`；全文统计不能回流为历史预测信息。

按照开发规范，每次新增、移动或删除核心文件后，同步更新本目录树、对应注释及入口链接。目录树描述实际已有文件；历史审查、模板示例和已完成任务笔记均按其真实用途标注。


2026-09-11存储清理：保留两问当前版、上一版及旧迁移验收目录；旧运行必要记录见 [压缩归档](outputs/history/run_records_20260911.tar.gz)、[逐文件清单](outputs/history/cleanup_20260911.csv) 和 [验收记录](outputs/history/cleanup_20260911.json)。已清理目录不能作为完整运行代恢复；当前输入、数值结果和图表原样保留。此次为一次性清理，生成器尚未自动限制历史数量。

集中绘图：`python3 src/plots/run.py q1`重绘第一问8张新论文图；`python3 src/plots/run.py q2`重绘第二问11张分析图；`all`执行两者。项目自写绘图实现统一保存在`src/plots/`，原求解入口保留兼容调用；新图PNG为300 dpi、SVG为矢量路径，数据表用CSV。8张新图按论文必要性标注，运行结果图为核心必选，费用对比建议，其余按论证选用。详见[本轮验收](docs/plots/acceptance.md)。

绘图输出格式：所有项目绘图脚本统一只生成PNG和SVG；已取消旧Q1脚本的PDF导出。目录树中的绘图PDF是旧运行代遗留文件。

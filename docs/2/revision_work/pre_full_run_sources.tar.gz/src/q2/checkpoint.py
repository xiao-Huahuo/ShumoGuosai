"""完整日前缀验收；数值损坏、跨日断链及未提交的CSV均禁止续算。"""

import json

import numpy as np
import pandas as pd

from data import sha256, write_csv, write_json
from export_dispatch import validate_dispatch
from policy import DT, PHYSICAL_TOL, Policy, replay

TABLES = ("dispatch.csv", "daily.csv", "calibration.csv")


def save_checkpoint(output, frame, daily, calibration):
    for name, table in zip(TABLES, (frame, pd.DataFrame(daily), pd.DataFrame(calibration))):
        pending = output/(name+".pending")
        write_csv(pending, table)
        pending.replace(output/name)
    pending = output/"checkpoint.pending.json"
    write_json(pending, {"days": len(daily), "sha256": {name: sha256(output/name) for name in TABLES}})
    pending.replace(output/"checkpoint.json")


def read_checkpoint(output, actual, dates, prices, initial_soc, start, end, settings):
    status = json.loads((output/"run_status.json").read_text(encoding="utf-8"))
    if status.get("settings") != settings or status.get("start_index") != start or status.get("end_index") != end:
        raise ValueError("已有回放与当前实验设置不同，拒绝覆盖")
    manifest = output/"checkpoint.json"
    if manifest.exists():
        hashes = json.loads(manifest.read_text(encoding="utf-8"))["sha256"]
        if any(sha256(output/name) != digest for name, digest in hashes.items()):
            raise ValueError("检查点摘要不符或CSV事务尚未完整提交")
    previous = pd.read_csv(output/"dispatch.csv", parse_dates=["date", "timestamp"], float_precision="round_trip")
    completed = previous.date.nunique()
    if completed > end-start or not np.array_equal(previous.date.unique(), dates[start:start+completed].to_numpy()):
        raise ValueError("回放检查点不是完整连续前缀")
    rigid = settings.get("kind") == "rigid"
    validate_dispatch(previous, rigid=rigid)
    np.testing.assert_allclose(previous.initial_soc.iloc[0], initial_soc, atol=PHYSICAL_TOL, rtol=0)
    expected_net = DT*(actual[start:start+completed, :, 0]-actual[start:start+completed, :, 1]).ravel()
    np.testing.assert_allclose(previous.net_kwh, expected_net, atol=PHYSICAL_TOL, rtol=0)
    np.testing.assert_array_equal(previous.price, np.tile(prices, completed))
    daily = pd.read_csv(output/"daily.csv", float_precision="round_trip")
    calibration = pd.read_csv(output/"calibration.csv", float_precision="round_trip")
    if len(daily) != completed or daily.date.tolist() != [str(d.date()) for d in dates[start:start+completed]]:
        raise ValueError("逐日摘要与检查点日期不一致")
    for i, (date, day) in enumerate(previous.groupby("date", sort=False)):
        audit = json.loads((output/f"daily_audit/{date.date()}.json").read_text(encoding="utf-8"))
        frozen = pd.read_csv(output/f"frozen_plans/{date.date()}.csv", float_precision="round_trip")
        k = audit["selected_K"]
        if len(frozen) != k*144 or not audit[str(k)]["selected_solver"]["reliable"]:
            raise ValueError("冻结策略长度或求解验收状态不符")
        for key in ("grid", "charge_cap", "discharge_cap"):
            np.testing.assert_array_equal(frozen[key].iloc[:144], day[key])
        if not rigid:
            policy = Policy(day.grid, day.charge_cap, day.discharge_cap)
            response = replay(policy, day.net_kwh.to_numpy(), float(day.initial_soc.iloc[0]))
            for key, values in response.items():
                np.testing.assert_allclose(day[key], values, atol=PHYSICAL_TOL, rtol=0)
        row = daily.iloc[i]
        np.testing.assert_allclose([row.initial_soc, row.final_soc, row.cost, row.emergency_kwh],
                                   [day.initial_soc.iloc[0], day.soc.iloc[-1],
                                    (day.planned_cost+day.emergency_cost).sum(), day.emergency.sum()],
                                   atol=PHYSICAL_TOL, rtol=0)
        observed = calibration[calibration.origin == str(date.date())]
        expected = {(h, nominal) for h in range(min(k, len(dates)-start-i)) for nominal in (.8, .9)}
        if len(observed) != len(expected) or set(zip(observed.horizon, observed.nominal)) != expected:
            raise ValueError("预测步长覆盖率记录缺失或重复")
    return previous, daily.to_dict("records"), calibration.to_dict("records")

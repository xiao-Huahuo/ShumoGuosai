"""最终方案2.9/2.10：先冻结首日策略，再逐步真实回放；求解受限显式记录。"""

import numpy as np
import pandas as pd
import json
from pathlib import Path

from comparators import deterministic_policy, rigid_schedule
from checkpoint import read_checkpoint, save_checkpoint
from data import calendar_for_day, sha256, write_csv, write_json
from forecast import seasonal
from optimization import certify_policy, solve_policy
from relaxation import recourse_bound
from policy import DT, E_INITIAL, Policy, replay, validate_replay
from protocol import PROTOCOL
from scenarios import construct, quantile_comparison, weighted_quantile
from shadows import choose_day


class ComputationalLimit(RuntimeError):
    def __init__(self, details):
        super().__init__("未获得满足预注册MIP gap及映射验收的策略；不得当正式解发布")
        self.details = details


def _solve(net, prices, weights, soc, **options):
    if len(net) == 1:
        policy, responses, info = deterministic_policy(net[0], prices, soc)
        if policy is not None:
            return policy, responses, info
    mean = np.average(net, weights=weights, axis=0)
    seed, _, _ = deterministic_policy(mean, prices, soc)
    bound_policy, bound_responses, bound = recourse_bound(net, prices, weights, soc, target_gap=PROTOCOL["solver_gap"])
    if bound["certified_gap"] <= PROTOCOL["solver_gap"]:
        return certify_policy(net, prices, weights, soc, bound_policy, bound_responses, bound, PROTOCOL["solver_gap"])
    if seed is None or sum(p*(prices@(seed.grid+5*replay(seed, path, soc)["emergency"])) for p, path in zip(weights, net)) > bound["incumbent_cost"]:
        seed = bound_policy
    return solve_policy(net, prices, weights, soc, gap=PROTOCOL["solver_gap"],
                        time_limit=PROTOCOL["solver_seconds"], seed_policy=seed,
                        known_lower_bound=bound["lower_bound"], **options)


def _pool_cost(policy, net, prices, soc):
    return float(np.mean([5*np.dot(prices[:144], replay(policy.first(), path[:144], soc)["emergency"]) for path in net]))


def select_resolution(point, blocks, prices, soc, *, forced_count=None):
    full_net, full_weights, _ = construct(point, blocks, prices)
    m = len(blocks)
    counts = [m] if m <= 40 else [10, 20, 40]
    if forced_count is not None and m > 40:
        counts = [min(m, forced_count)]
    results, audit = {}, {"M": m, "candidates": {}, "computational_limited": False}
    for count in counts:
        net, weights, scenario = construct(point, blocks, prices, count)
        policy, responses, info = _solve(net, prices, weights, soc)
        item = {"scenarios": scenario, "solver": info}
        if policy is not None:
            item["full_pool_first_day_emergency_cost"] = _pool_cost(policy, full_net, prices, soc)
            item["scenario_first_day_emergency_cost"] = float(sum(5*p*np.dot(prices[:144], r["emergency"][:144]) for p, r in zip(weights, responses)))
            item["tail_quantiles"] = quantile_comparison(full_net, net, weights)
        audit["candidates"][str(count)] = item
        if policy is not None and info["reliable"]:
            results[count] = (policy, responses, weights, net)
    if not results:
        raise ComputationalLimit(audit)
    selected = max(results)
    if m > 40 and forced_count is None:
        if 20 in results and 40 in results:
            j20, j40 = [audit["candidates"][str(s)]["solver"]["objective"] for s in (20, 40)]
            g20, g40 = results[20][0].grid[:144], results[40][0].grid[:144]
            dj = abs(j40-j20)/max(abs(j40), 1e-8)
            dg = float(np.abs(g40-g20).sum()/max(g40.sum(), 1e-8))
            audit.update(delta_J_20_40=dj, delta_g_20_40=dg)
            if dj <= PROTOCOL["stability_objective_relative"] and dg <= PROTOCOL["stability_grid_relative"]:
                selected = 20
        else:
            audit["computational_limited"] = True
        def tail_bad(count):
            entry = audit["candidates"][str(count)]
            quantile_bad = max(v["normalized_error"] for v in entry["tail_quantiles"].values()) > PROTOCOL["tail_quantile_relative"]
            reference = audit["candidates"].get("40", entry).get("full_pool_first_day_emergency_cost", 0)
            deterioration = (entry["full_pool_first_day_emergency_cost"]-reference)/max(reference, 1e-8)
            return quantile_bad or deterioration > PROTOCOL["full_pool_emergency_relative"]
        if selected == 20 and tail_bad(20) and 40 in results:
            selected = 40
        if selected == 40 and tail_bad(40):
            policy, responses, info = _solve(full_net, prices, full_weights, soc)
            audit["candidates"][str(m)] = {"solver": info, "scenarios": {"M": m, "S": m, "reduced": False}, "trigger": "tail_check_failed_at_40"}
            if policy is not None and info["reliable"]:
                results[m] = (policy, responses, full_weights, full_net)
                selected = m
            else:
                audit["computational_limited"] = True
                audit["tail_requirement_unresolved"] = True
    policy, responses, weights, net = results[selected]
    audit.update(S=selected, selected_solver=audit["candidates"][str(selected)]["solver"])
    return policy, responses, weights, net, audit


def make_day(store, frozen, history, d, prices, soc, *, horizon="auto", minimum=14,
             window="auto", forced_count=None, fixed_pair=None, kind="feedback"):
    candidates = (1, 2, 3) if horizon == "auto" else (int(horizon),)
    results, audits = {}, {}
    for k in candidates:
        point, blocks, selection = choose_day(store, frozen, history, d, k, prices, minimum=minimum,
                                             window=window, fixed_pair=fixed_pair)
        selection["common_scored_origins"] = [int(j) for j in selection["common_scored_origins"]]
        price_horizon = np.tile(prices, k)
        try:
            if kind == "deterministic":
                net = DT*(point[..., 0]-point[..., 1]).reshape(1, -1)
                policy, responses, solver = _solve(net, price_horizon, np.array([1.]), soc)
                if policy is None or not solver["reliable"]:
                    raise ComputationalLimit(solver)
                weights = np.array([1.]); audit = {"M": len(blocks), "S": 1, "selected_solver": solver}
            elif kind == "rigid":
                if forced_count is None:
                    _, _, weights, net, audit = select_resolution(point, blocks, price_horizon, soc)
                else:
                    net, weights, scenarios = construct(point, blocks, price_horizon, forced_count)
                    audit = {"M": len(blocks), "S": len(weights), "scenarios": scenarios}
                grid, responses, solver = rigid_schedule(net, price_horizon, weights, soc)
                policy = Policy(grid, responses[0]["charge"], responses[0]["discharge"])
                audit["selected_solver"] = solver
            else:
                policy, responses, weights, net, audit = select_resolution(point, blocks, price_horizon, soc, forced_count=forced_count)
        except ComputationalLimit as error:
            audits[str(k)] = {"selection": selection, "error": error.details}
            continue
        day_cost = float(prices@policy.grid[:144] + sum(5*p*(prices@r["emergency"][:144]) for p, r in zip(weights, responses)))
        audit.update(selection=selection, first_day_expected_cost=day_cost)
        audits[str(k)] = audit
        results[k] = (policy, weights, net, point)
    if not results:
        raise ComputationalLimit(audits)
    selected = max(results)
    if horizon == "auto" and 2 in results and 3 in results:
        g2, g3 = results[2][0].grid[:144], results[3][0].grid[:144]
        dg = float(np.abs(g2-g3).sum()/max(g3.sum(), 1e-8))
        c2, c3 = audits["2"]["first_day_expected_cost"], audits["3"]["first_day_expected_cost"]
        dc = abs(c2-c3)/max(abs(c3), 1e-8)
        audits["stability_48_72"] = {"grid_relative": dg, "first_day_expected_cost_relative": dc,
                                      "interpretation": "open_loop_first_day_stability_only"}
        if dg <= PROTOCOL["stability_grid_relative"] and dc <= PROTOCOL["stability_objective_relative"]:
            selected = 2
    audits["selected_K"] = selected
    audits["computational_limited"] = len(results) < len(candidates) or any(v.get("computational_limited", False) for v in audits.values() if isinstance(v, dict))
    return *results[selected], audits


def dispatch_frame(date, policy, net, soc, prices, *, rigid=False):
    first = policy.first()
    if rigid:
        charge, discharge = first.charge_cap, first.discharge_cap
        gap = net+charge-first.grid-discharge
        response = {"charge": charge, "discharge": discharge, "emergency": np.maximum(gap, 0),
                    "unused": np.maximum(-gap, 0), "soc": soc+np.cumsum(.9*charge-discharge/.9)}
        validate_replay(first.grid, net, soc, response, rigid=True)
    else:
        response = replay(first, net, soc)
    frame = calendar_for_day(date)
    frame["day_of_year"] = pd.Timestamp(date).dayofyear
    frame["grid"] = first.grid
    frame["charge_cap"] = first.charge_cap
    frame["discharge_cap"] = first.discharge_cap
    frame["net_kwh"] = net
    frame["initial_soc"] = soc
    frame["price"] = prices
    for key, value in response.items():
        frame[key] = value
    frame["planned_cost"] = prices*first.grid
    frame["emergency_cost"] = 5*prices*response["emergency"]
    return frame


def warm_start(actual, dates, prices, output):
    """1—7日仅积累观测且储能停机；8—31日固定季节基线+K=2确定性同模型。"""
    soc = E_INITIAL
    records, solver_records = [], []
    for d in range(7, 31):
        prediction = seasonal(actual[:d].copy(), 2)
        net = DT*(prediction[..., 0]-prediction[..., 1]).ravel()
        policy, _, info = _solve(net[None], np.tile(prices, 2), np.array([1.]), soc)
        if policy is None or not info["reliable"]:
            raise ComputationalLimit({"warm_date": str(dates[d]), "solver": info})
        frame = dispatch_frame(dates[d], policy, DT*(actual[d, :, 0]-actual[d, :, 1]), soc, prices)
        records.append(frame); solver_records.append({"date": str(dates[d]), **info})
        soc = float(frame.soc.iloc[-1])
    write_csv(output/"warm_dispatch.csv", pd.concat(records, ignore_index=True))
    write_json(output/"warm_start.json", {"initial_soc_jan1": E_INITIAL, "jan1_jan7_charge_discharge": 0,
                                         "warm_horizon": 2, "feb1_baseline_soc": soc,
                                         "interpretation": "causal_initialization_not_recovered_true_state",
                                         "solver_records": solver_records})
    return soc


def run_rollout(store, frozen, actual, dates, prices, initial_soc, output, *, start=31, end=None,
                reference_audits=None, **settings):
    output.mkdir(parents=True, exist_ok=True)
    end = len(dates) if end is None else end
    source_hashes = {p.name: sha256(p) for p in Path(__file__).parent.glob("*.py")}
    soc, frames, daily, calibration = initial_soc, [], [], []
    resume_at = start
    if (output/"dispatch.csv").exists():
        previous, daily, calibration = read_checkpoint(output, actual, dates, prices, initial_soc, start, end, settings)
        completed = previous.date.nunique()
        frames = [previous]
        soc = float(previous.soc.iloc[-1]); resume_at += completed
        print(f"从已验收的{completed}日连续回放检查点续算", flush=True)
    write_json(output/"run_status.json", {"complete": False, "settings": settings, "start_index": start, "end_index": end})
    for d in range(resume_at, end):
        daily_settings = dict(settings)
        if reference_audits is not None:
            reference = json.loads((reference_audits/f"{pd.Timestamp(dates[d]).date()}.json").read_text(encoding="utf-8"))
            chosen = reference[str(reference["selected_K"])]
            daily_settings.update(horizon=reference["selected_K"], forced_count=chosen["S"],
                                  fixed_pair=chosen["selection"]["pipeline"])
        try:
            policy, weights, net_scenarios, point, audit = make_day(store, frozen, actual[:d], d, prices, soc, **daily_settings)
        except ComputationalLimit as error:
            write_json(output/"run_status.json", {"complete": False, "settings": settings,
                                                 "start_index": start, "end_index": end,
                                                 "failed_date": str(dates[d]), "reason": str(error), "solver_details": error.details})
            raise
        audit["source_sha256_at_rollout_start"] = source_hashes
        write_json(output/f"daily_audit/{pd.Timestamp(dates[d]).date()}.json", audit)
        write_csv(output/f"frozen_plans/{pd.Timestamp(dates[d]).date()}.csv", pd.DataFrame({
            "step": np.arange(len(policy.grid)), "grid": policy.grid,
            "charge_cap": policy.charge_cap, "discharge_cap": policy.discharge_cap,
            "role": np.where(np.arange(len(policy.grid)) < 144, "first_day_frozen", "open_loop_proxy_only")}))
        # 到此之前当日actual[d]未进入任何选模、场景或求解调用。
        net = DT*(actual[d, :, 0]-actual[d, :, 1])
        frame = dispatch_frame(dates[d], policy, net, soc, prices, rigid=settings.get("kind") == "rigid")
        frame["predicted_load_kw"] = point[0, :, 0]
        frame["predicted_pv_kw"] = point[0, :, 1]
        frames.append(frame)
        selected_k = audit["selected_K"]
        daily.append({"date": str(pd.Timestamp(dates[d]).date()), "K": selected_k,
                      "M": audit[str(selected_k)]["M"], "S": len(weights),
                      "initial_soc": soc, "final_soc": float(frame.soc.iloc[-1]),
                      "cost": float(frame.planned_cost.sum()+frame.emergency_cost.sum()),
                      "emergency_kwh": float(frame.emergency.sum()),
                      "computational_limited": audit["computational_limited"]})
        for h in range(min(selected_k, len(dates)-d)):
            realized = DT*(actual[d+h, :, 0]-actual[d+h, :, 1])
            scenario = net_scenarios[:, h*144:(h+1)*144]
            for nominal, low, high in ((.8, .1, .9), (.9, .05, .95)):
                lower, upper = weighted_quantile(scenario, weights, low), weighted_quantile(scenario, weights, high)
                calibration.append({"origin": str(pd.Timestamp(dates[d]).date()), "horizon": h, "nominal": nominal,
                                    "covered_intervals": int(((realized >= lower)&(realized <= upper)).sum()),
                                    "n": 144, "picp": float(((realized >= lower)&(realized <= upper)).mean())})
        soc = float(frame.soc.iloc[-1])
        save_checkpoint(output, pd.concat(frames, ignore_index=True), daily, calibration)
        print(f"真实回放 {pd.Timestamp(dates[d]).date()} K={selected_k} S={len(weights)} SOC={soc:.3f}", flush=True)
    write_json(output/"run_status.json", {"complete": True, "settings": settings, "days": len(daily),
                                         "start_index": start, "end_index": end,
                                         "initial_soc": initial_soc, "final_soc": soc,
                                         "full_evaluation_period": start == 31 and end == 365})
    return pd.concat(frames, ignore_index=True), pd.DataFrame(daily)
